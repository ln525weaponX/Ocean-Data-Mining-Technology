# 检查点在线调度与公开 AIS 验证 V2

本项目与修订报告一致。公开AIS提供事实负载；到达时间、检查点成本、故障和硬件能力是显式仿真条件。SQLite另行执行真实单数据库原子事务核验。

## 本版变化

- 上传量统一为固定元数据加每条更新增量；每船完整状态只进入恢复读取。
- 候选等待时间进入快照大小和耗时，整数可行域用二分求解；空集合显式记为-1。
- 速率估计包含波动余量、积压下限与能力上限。0.75为经验系数。
- 暴露率在故障回滚前采样，限定故障注入时域并排除恢复暂停。
- 同时输出最大等待、超时条数、回滚关联、阻塞周期及连续事件、写入成本分解。

## 运行

建议Python 3.10或以上。先在解压根目录执行：

    pip install -r requirements.txt
    python src/study.py
    python src/transaction_check.py
    python src/make_figures.py
    python src/build_notebook.py
    python src/verify_results.py

也可直接在根目录打开已执行的检查点调度_AIS复现实验V2.ipynb。运行时保持data、src、results、figures目录完整。

重建Word另需Pandoc，建议安装Noto Serif CJK SC与XITS Math字体：

    python src/revise_report.py

report/source_v1.docx保存用户提供的底稿，程序保留第1至6节课程内容并统一引用编号；report/model_core.md是包含原生公式的模型文本源。

## 实验数量

- 固定基线校准144次，只使用前8小时与种子0至7。
- 留出主实验800次：5场景、8策略、20共同故障种子。
- 固定间隔诊断扫描72次，不用于调参。
- 15组敏感性条件各重新校准，含1080次校准及180次留出运行。
- 无故障对照10次。
- 实际SQLite原子事务24次，非原子反例12次。

legacy保留V1瞬时触发规则，但使用V2统一上传模型和统计口径。历史V1封顶审计只作模型诊断，不参与V2调参。

## 数据与来源

公开样本84702行、100个不同MMSI，时间为2017年7月5日，丹麦海事管理局发布、MovingPandas提供哥德堡附近样本。

https://github.com/movingpandas/movingpandas-examples/blob/main/data/README.md

固定原文件：

https://raw.githubusercontent.com/movingpandas/movingpandas-examples/5e67be5df737ca7a5af321e8524e7691dd8dddf9/data/ais.gpkg

压缩包已附完整所用字段CSV，不重复打包GeoPackage。python src/download_data.py可重新下载并核对原文件及提取哈希。未使用船名或几何坐标。

## 指标解释

发布等待自首次处理完成计时，故障后不重新起表；P99验收与单条最大等待分别报告。各阻塞原因可能重叠，不能把分项直接相加作为总阻塞次数。发生回滚的超时记录具有恢复关联，该标记不替代完整因果分析。

超预算暴露率是运行指标，其概率解释需额外故障假设。故障命中比例无故障时未定义。所有时间均为12倍速回放时钟，不能直接外推为真实Flink性能。

本版通过额外的预测保护换取较低暴露率，写入节省幅度与旧版不同；不将版本变化解释为所有性能指标全面改善。资源节省仍伴随等待与故障重算的权衡。
