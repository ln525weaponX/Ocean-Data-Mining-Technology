"""Actual SQLite failure-injection check of atomic progress + non-idempotent counts.

The audit table deliberately has NO unique constraint on source record IDs.
Correctness comes from the transaction containing effect + cursor, not audit
deduplication. These are single-database tests, not a distributed Flink proof.
"""
from __future__ import annotations
import collections, hashlib, json, sqlite3, tempfile
from pathlib import Path
import numpy as np
import pandas as pd
from study import Config, ROOT, make_trace, simulate

def run_trial(rows, boundaries, seed, atomic=True, broken_order='effect_first'):
    rng=np.random.default_rng(seed)
    expected_ids={int(x[0]) for x in rows}
    expected_counts=collections.Counter(int(x[1]) for x in rows)
    with tempfile.TemporaryDirectory(prefix='checkpoint_tx_') as td:
        db=Path(td)/'state.sqlite'
        con=sqlite3.connect(db)
        con.executescript('''PRAGMA journal_mode=WAL;
        PRAGMA synchronous=FULL;
        CREATE TABLE cursor_state(id INTEGER PRIMARY KEY,pos INTEGER NOT NULL);
        INSERT INTO cursor_state VALUES(1,0);
        CREATE TABLE counts(win INTEGER PRIMARY KEY,reports INTEGER NOT NULL);
        CREATE TABLE audit(fid INTEGER NOT NULL);
        CREATE TABLE ships(win INTEGER,mmsi INTEGER,PRIMARY KEY(win,mmsi));''')
        con.commit();attempts=0;crashes=0;after_commit_lost_ack=0
        used_failure=set();pos=0
        while pos<len(rows):
            pos=con.execute('SELECT pos FROM cursor_state WHERE id=1').fetchone()[0]
            if pos>=len(rows):break
            end=next(x for x in boundaries if x>pos)
            batch=rows[pos:end]
            attempts+=1
            # One planned fault per selected checkpoint boundary; retry can finish.
            stage=int(rng.integers(0,4)) if end not in used_failure and rng.random()<.40 else -1
            if stage>=0:used_failure.add(end)
            def effects():
                bc=collections.Counter(int(x[1]) for x in batch)
                for w,c in bc.items():
                    con.execute('INSERT INTO counts VALUES(?,?) ON CONFLICT(win) DO UPDATE '
                                'SET reports=reports+excluded.reports',(w,c))
                con.executemany('INSERT INTO audit(fid) VALUES(?)',[(int(x[0]),) for x in batch])
                con.executemany('INSERT OR IGNORE INTO ships VALUES(?,?)',[(int(x[1]),int(x[2])) for x in batch])
            try:
                if stage==0:raise RuntimeError('before_transaction')
                if atomic:
                    con.execute('BEGIN IMMEDIATE');effects()
                    if stage==1:raise RuntimeError('after_effect_before_progress')
                    con.execute('UPDATE cursor_state SET pos=? WHERE id=1',(end,))
                    if stage==2:raise RuntimeError('after_progress_before_commit')
                    con.commit()
                elif broken_order=='effect_first':
                    con.execute('BEGIN IMMEDIATE');effects();con.commit()
                    if stage in (1,2):raise RuntimeError('effect_committed_progress_missing')
                    con.execute('UPDATE cursor_state SET pos=? WHERE id=1',(end,));con.commit()
                else:
                    con.execute('UPDATE cursor_state SET pos=? WHERE id=1',(end,));con.commit()
                    if stage in (1,2):raise RuntimeError('progress_committed_effect_missing')
                    effects();con.commit()
                if stage==3:
                    after_commit_lost_ack+=1
                    raise RuntimeError('commit_succeeded_ack_lost')
            except RuntimeError:
                crashes+=1;con.close();con=sqlite3.connect(db)
                con.execute('PRAGMA synchronous=FULL')
        counts=dict(con.execute('SELECT win,reports FROM counts'))
        aud=dict(con.execute('SELECT fid,COUNT(*) FROM audit GROUP BY fid'))
        missing=len(expected_ids-set(aud))
        duplicates=sum(max(0,v-1) for v in aud.values())
        distinct=con.execute('SELECT count(*) FROM ships').fetchone()[0]
        expected_distinct=len({(int(x[1]),int(x[2])) for x in rows})
        result={'seed':seed,'atomic':atomic,'broken_order':broken_order,'records':len(rows),
                'attempts':attempts,'injected_crashes':crashes,
                'commit_ack_losses':after_commit_lost_ack,
                'missing_effects':missing,'duplicate_effects':duplicates,
                'window_counts_equal':counts==dict(expected_counts),
                'distinct_pairs_equal':distinct==expected_distinct,
                'final_cursor':con.execute('SELECT pos FROM cursor_state').fetchone()[0]}
        con.close();return result

def main():
    df=pd.read_csv(ROOT/'data/ais_records.csv',parse_dates=['ts'])
    cfg=Config();tr=make_trace(df,'test','combined',cfg)
    selected=json.loads((ROOT/'results/experiment_plan.json').read_text())['selected_fixed_interval']
    lookup=df.set_index('fid');out=[]
    for policy in ('fixed','adaptive'):
        _,_,cps,_=simulate(tr,policy,cfg,100,selected,True)
        n=8000
        ids=tr['fid'][:n]
        rows=[(int(fid),int(lookup.loc[fid,'ts'].value//(600*10**9)),int(lookup.loc[fid,'MMSI'])) for fid in ids]
        boundaries=sorted({int(v) for v in cps.loc[cps.success,'captured'] if 0<int(v)<n}|{n})
        for seed in range(12):
            r=run_trial(rows,boundaries,seed,True);r['policy']=policy;out.append(r)
        for broken in ('effect_first','progress_first'):
            for seed in range(3):
                r=run_trial(rows,boundaries,seed,False,broken);r['policy']=policy;out.append(r)
    result=pd.DataFrame(out);result.to_csv(ROOT/'results/transaction_fault_tests.csv',index=False)
    good=result[result.atomic]
    assert good.missing_effects.sum()==good.duplicate_effects.sum()==0
    assert good.window_counts_equal.all() and good.distinct_pairs_equal.all()
    summary={'atomic_trials':len(good),'records_per_trial':8000,
             'injected_crashes':int(good.injected_crashes.sum()),
             'commit_ack_losses':int(good.commit_ack_losses.sum()),
             'missing_effects':int(good.missing_effects.sum()),
             'duplicate_effects':int(good.duplicate_effects.sum()),
             'all_counts_equal':bool(good.window_counts_equal.all()),
             'negative_controls':result[~result.atomic].groupby('broken_order')[['missing_effects','duplicate_effects']].sum().to_dict('index')}
    (ROOT/'results/transaction_check_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
