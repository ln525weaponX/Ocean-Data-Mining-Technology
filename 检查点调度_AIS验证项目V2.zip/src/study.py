"""Trace-driven checkpoint scheduling study. Python 3.10+, numpy, pandas.

All times in the simulator are replay seconds. AIS event time is preserved
separately; event-time compression, outages, storage and failures are explicit
experimental assumptions, not measurements of the public AIS source.
"""
from __future__ import annotations
import argparse, dataclasses, hashlib, json, math, sqlite3, time
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

@dataclasses.dataclass(frozen=True)
class Config:
    compression: float = 12.0
    capacity: float = 48.0
    checkpoint_base: float = 1.5
    metadata_bytes: float = 16384.0
    bytes_per_update: float = 128.0
    state_bytes_per_ship: float = 4096.0
    bandwidth: float = 65536.0
    processing_penalty: float = 0.35
    recovery_seconds: float = 8.0
    recovery_bandwidth: float = 262144.0
    min_pause: float = 1.0
    min_interval: float = 3.0
    max_interval: float = 120.0
    visible_budget: float = 60.0
    replay_budget: float = 600.0
    ewma_alpha: float = 0.08
    guard_sigma: float = 0.75
    failure_mean: float = 900.0

FIXED_INTERVALS = (5, 10, 15, 20, 30, 45, 60, 90, 120)

def future_duration(pending, rate, wait, bandwidth, cfg):
    """Upload size grows before capture; this is a prediction, not a bound."""
    size=cfg.metadata_bytes+cfg.bytes_per_update*(pending+rate*wait)
    return math.ceil(cfg.checkpoint_base+size/max(1.,bandwidth))

def latest_wait(pending, age, rate, bandwidth, elapsed, cfg, policy='adaptive'):
    """Exact integer search for the frozen-coefficient local feasible set.

    -1 explicitly denotes no feasible wait, including an infeasible immediate
    checkpoint. The controller never labels that state as a proven guarantee.
    """
    limit=math.floor(cfg.max_interval-elapsed)
    if limit<0:return -1
    def feasible(h):
        duration=future_duration(pending,rate,h,bandwidth,cfg)
        age_ok=policy=='no_age' or age+h+duration+1<=cfg.visible_budget
        reserve=0 if policy=='no_forecast' else duration+1
        work_ok=pending+rate*(h+reserve)<=cfg.replay_budget
        return age_ok and work_ok
    if not feasible(0):return -1
    lo,hi=0,limit
    while lo<hi:
        mid=(lo+hi+1)//2
        if feasible(mid):lo=mid
        else:hi=mid-1
    return lo

def prepare_data():
    """Extract factual non-geometry fields from the pinned public GeoPackage."""
    src = ROOT/'data/ais.gpkg'
    if not src.exists():
        import urllib.request
        meta = json.loads((ROOT/'provenance/download.json').read_text())
        with urllib.request.urlopen(meta['url'], timeout=90) as r:
            src.write_bytes(r.read())
        if hashlib.sha256(src.read_bytes()).hexdigest() != meta['sha256']:
            raise ValueError('Source SHA256 mismatch')
    with sqlite3.connect(src) as con:
        df = pd.read_sql_query('SELECT fid,Timestamp,MMSI,SOG,COG,NavStatus,ShipType '
                               'FROM aisdk_20170705_gothenburg2', con)
    df['ts'] = pd.to_datetime(df.pop('Timestamp'), format='%d/%m/%Y %H:%M:%S')
    df = df.sort_values(['ts','fid'], kind='stable').reset_index(drop=True)
    df.to_csv(ROOT/'data/ais_records.csv', index=False)
    hourly=df.groupby(df.ts.dt.hour).size()
    minute=df.groupby(df.ts.dt.floor('min')).size()
    stats={'records':len(df),'ships':int(df.MMSI.nunique()),
           'start':str(df.ts.min()),'end':str(df.ts.max()),
           'hourly_records':{str(k):int(v) for k,v in hourly.items()},
           'minute_count_quantiles':{str(k):float(v) for k,v in minute.quantile([0,.1,.5,.9,.99,1]).items()},
           'sog_missing':int(df.SOG.isna().sum()), 'cog_missing':int(df.COG.isna().sum()),
           'repeated_attribute_rows':int(df.duplicated(['ts','MMSI','SOG','COG']).sum()),
           'train_records':int((df.ts.dt.hour<8).sum()),
           'test_records':int((df.ts.dt.hour>=8).sum())}
    (ROOT/'results/dataset_statistics.json').write_text(json.dumps(stats,indent=2))
    hourly.rename('records').to_csv(ROOT/'data/hourly_counts.csv',index_label='hour')
    minute.rename('records').to_csv(ROOT/'data/minute_counts.csv',index_label='timestamp')
    return df

def make_trace(df:pd.DataFrame, split:str, scenario:str, cfg:Config):
    start=pd.Timestamp('2017-07-05 00:00:00' if split=='train' else '2017-07-05 08:00:00')
    end=pd.Timestamp('2017-07-05 08:00:00' if split=='train' else '2017-07-06 00:00:00')
    x=df[(df.ts>=start)&(df.ts<end)].copy()
    event=(x.ts-start).dt.total_seconds().to_numpy()/cfg.compression
    horizon=(end-start).total_seconds()/cfg.compression
    arrival=event.copy()
    if scenario in ('outage2h','outage6h','combined'):
        hours=6 if scenario=='outage6h' else 2
        outage_start=.28*horizon
        outage_duration=hours*3600/cfg.compression
        outage_end=outage_start+outage_duration
        mask=(event>=outage_start)&(event<outage_end)
        # Assumed six-times-speed replay of held records. Live input continues.
        arrival[mask]=outage_end+(event[mask]-outage_start)/6.0
    order=np.lexsort((x.fid.to_numpy(),arrival))
    arrival=arrival[order]
    ships=x.MMSI.to_numpy()[order]
    seen=set(); unique=np.zeros(len(ships)+1,dtype=np.int32)
    for i,s in enumerate(ships,1):
        seen.add(int(s)); unique[i]=len(seen)
    return {'arrival':arrival,'event':event[order], 'fid':x.fid.to_numpy()[order],
            'ship':ships, 'prefix_ships':unique,'horizon':int(horizon),
            'scenario':scenario,'split':split,'n':len(x)}

def failure_times(seed:int,horizon:int,mean:float):
    if mean<=0:return np.empty(0,dtype=int)
    rng=np.random.default_rng(seed)
    out=[]; t=0.
    while True:
        t+=rng.exponential(mean)
        if t>=horizon:break
        out.append(int(t))
    return np.unique(out)

def simulate(trace, policy:str,cfg:Config,seed:int=0,fixed:float=30.,keep_log:bool=False):
    """One global consistent snapshot; atomic visible-prefix commit.

    Snapshots capture only complete processed records. A failure rolls processing
    back to the last durable committed prefix. Uncommitted snapshots are aborted.
    Processing continues during checkpoint IO at the configured reduced capacity.
    This is an explicit fluid/discrete simulator, not a Flink implementation.
    """
    arr=trace['arrival']; n=len(arr); horizon=trace['horizon']
    arrivals_per_tick=np.bincount(np.ceil(arr).astype(int),minlength=horizon+2)
    cum=np.cumsum(arrivals_per_tick)
    max_steps=max(horizon,int(math.ceil(arr[-1])))+7200
    faults=failure_times(seed,horizon,cfg.failure_mean)
    fault_set=set(faults.tolist())
    p=0.; committed=0; cp=None; recovery_until=-1.
    first_ready=np.full(n,np.nan); committed_at=np.full(n,np.nan)
    last_start=0.; last_complete=0.
    rate=0.; var=0.; bhat=cfg.bandwidth
    cp_count=0; success=0; aborted=0; bytes_started=0.; bytes_written=0.
    cp_durations=[]; lost_per_failure=[]; busy_ticks=0; risk_exceed=0; observed_ticks=0
    total_processed=0.; max_unprotected=0.; replay_sum=0.; records_lost=0
    log=[]; cp_log=[]
    rollback_seen=np.zeros(n,dtype=bool)
    exposure_ticks=exposure_exceed=active_faults=active_faults_exceed=0
    success_metadata=success_incremental=0.; failed_written=0.
    prediction_errors=[]; blocked_prev={k:False for k in ('inflight','pause','interval','recovery')}
    blocked_ticks={k:0 for k in blocked_prev};blocked_events={k:0 for k in blocked_prev}
    blocked_any_ticks=blocked_any_events=0;blocked_any_prev=False
    infeasible_requests=0;diagnostic_calls=0
    for t in range(max_steps):
        available=int(cum[min(t,len(cum)-1)])
        # Storage degradation is a declared perturbation, independent of policy.
        slow=(trace['scenario'] in ('io_slow','combined') and
              ((.18*horizon<=t<.36*horizon) or (.65*horizon<=t<.79*horizon)))
        bandwidth=cfg.bandwidth*(.25 if slow else 1.)
        # Match the exposure domain to the fault-injection domain and sample
        # the left-limit state BEFORE rollback or this tick's processing.
        before_risk=max(0,int(math.floor(p))-committed)
        exposed=(t<horizon and t>=recovery_until)
        if exposed:
            exposure_ticks+=1;exposure_exceed+=int(before_risk>cfg.replay_budget)
        if t in fault_set:
            lost=max(0,int(math.floor(p))-committed)
            lost_per_failure.append(lost); replay_sum+=lost
            if exposed:
                active_faults+=1;active_faults_exceed+=int(lost>cfg.replay_budget)
            rollback_seen[committed:int(math.floor(p))]=True
            p=float(committed)
            if cp is not None:
                failed_written+=cp['size']-cp['remaining']
                cp_log.append({'start':cp['start'],'end':t,'captured':cp['captured'],
                               'bytes':cp['size'],'success':False})
                aborted+=1; cp=None
            full=trace['prefix_ships'][committed]*cfg.state_bytes_per_ship
            recovery_until=t+cfg.recovery_seconds+full/cfg.recovery_bandwidth
            last_complete=t
        old=int(math.floor(p)); pending=max(0,old-committed)
        current_age=(t-first_ready[committed]) if pending else 0.
        full=max(1,int(trace['prefix_ships'][old]))*cfg.state_bytes_per_ship
        # Separate incremental upload cost from full-state recovery size.
        size=cfg.metadata_bytes+cfg.bytes_per_update*pending
        predicted_duration=math.ceil(cfg.checkpoint_base+size/max(1.,bhat))
        r_guard=max(rate,0.)+cfg.guard_sigma*math.sqrt(max(0.,var))
        if available-old>cfg.capacity*3:
            r_guard=max(r_guard,cfg.capacity*(1-cfg.processing_penalty))
        r_guard=min(cfg.capacity,r_guard)
        may_start=(cp is None and t>=recovery_until and pending>0 and
                   t-last_complete>=cfg.min_pause and t-last_start>=cfg.min_interval)
        # Blocked demand refers only to records not already captured by the
        # inflight checkpoint. Counts are decision ticks and contiguous episodes,
        # not a causal attribution of all eventual deadline misses.
        diag_cursor=cp['captured'] if cp is not None else committed
        diag_pending=max(0,old-diag_cursor)
        diag_age=t-first_ready[diag_cursor] if diag_pending else 0.
        diag_h=None
        demand=False
        if policy in ('adaptive','no_age','no_forecast') and diag_pending>0:
            diagnostic_calls+=1
            diag_h=latest_wait(diag_pending,diag_age,r_guard,bhat,t-last_start,cfg,policy)
            demand=diag_h<=1
        flags={'inflight':cp is not None,'pause':t-last_complete<cfg.min_pause,
               'interval':t-last_start<cfg.min_interval,'recovery':t<recovery_until}
        blocked_now={k:bool(demand and v) for k,v in flags.items()}
        any_blocked=any(blocked_now.values())
        blocked_any_ticks+=int(any_blocked)
        blocked_any_events+=int(any_blocked and not blocked_any_prev)
        blocked_any_prev=any_blocked
        for k,on in blocked_now.items():
            blocked_ticks[k]+=int(on);blocked_events[k]+=int(on and not blocked_prev[k])
        blocked_prev=blocked_now
        trigger=False; reason=''
        if may_start:
            if old==n:
                trigger=True; reason='final'
            elif policy=='fixed':
                trigger=t-last_start>=fixed; reason='timer'
            elif policy=='backlog':
                interval=fixed*3 if available-old>cfg.capacity*10 else fixed
                trigger=t-last_start>=min(cfg.max_interval,interval);reason='backlog_timer'
            elif policy=='rate':
                interval=float(np.clip(cfg.replay_budget/max(rate,.1),cfg.min_interval,cfg.max_interval))
                trigger=t-last_start>=interval;reason='rate_timer'
            elif policy=='count':
                trigger=pending>=cfg.replay_budget*.8 or t-last_start>=cfg.max_interval
                reason='count_budget'
            elif policy=='legacy':
                # V1 instantaneous rule, on the same V2 upload-cost model.
                reserve=r_guard*(predicted_duration+1)
                work_due=pending+reserve>=cfg.replay_budget
                age_due=current_age+predicted_duration+1>=cfg.visible_budget
                cap_due=t-last_start>=cfg.max_interval
                trigger=work_due or age_due or cap_due
                reason='work' if work_due else ('age' if age_due else 'cap')
            elif policy in ('adaptive','no_age','no_forecast'):
                assert diag_h is not None
                trigger=diag_h<=1
                reason=('cap' if t-last_start>cfg.max_interval else
                        'infeasible' if diag_h<0 else 'lookahead' if trigger else '')
            else:raise ValueError(policy)
        if trigger:
            if policy in ('adaptive','no_age','no_forecast') and diag_h is not None and diag_h<0:
                # An expired maximum-interval clock alone does not mean the
                # immediate age/work predictions are infeasible.
                infeasible_requests+=int(latest_wait(pending,current_age,r_guard,bhat,0,cfg,policy)<0)
            cp={'start':t,'captured':old,'size':size,'remaining':size,
                'base_remaining':cfg.checkpoint_base,'io_elapsed':0.,'reason':reason,
                'predicted_duration':predicted_duration,'pending':pending}
            last_start=t;cp_count+=1;bytes_started+=size
        if t>=recovery_until:
            cap=cfg.capacity*(1-cfg.processing_penalty if cp is not None else 1.)
            p=min(float(available),p+cap)
            done=int(math.floor(p)); amount=max(0,p-old)
            if done>old:
                inds=np.arange(old,done)
                missing=np.isnan(first_ready[inds]); first_ready[inds[missing]]=t+1
            total_processed+=amount
            delta=amount-rate;rate+=cfg.ewma_alpha*delta
            var=(1-cfg.ewma_alpha)*(var+cfg.ewma_alpha*delta*delta)
        else:
            done=int(math.floor(p))
        if cp is not None:
            busy_ticks+=1
            available_io=1.
            use=min(available_io,cp['base_remaining'])
            cp['base_remaining']-=use;available_io-=use
            if available_io>0:
                used=min(cp['remaining'],bandwidth*available_io)
                cp['remaining']-=used;bytes_written+=used
                cp['io_elapsed']+=used/bandwidth
            if cp['remaining']<=1e-7 and cp['base_remaining']<=1e-7:
                captured=cp['captured']
                assert committed<=captured<=int(math.floor(p))<=available<=n
                committed_at[committed:captured]=t+1
                committed=captured;success+=1;last_complete=t+1
                cp_durations.append(t+1-cp['start'])
                success_metadata+=cfg.metadata_bytes
                success_incremental+=cfg.bytes_per_update*cp['pending']
                prediction_errors.append(t+1-cp['start']-cp['predicted_duration'])
                measured=cp['size']/max(cp['io_elapsed'],1e-9)
                bhat=.3*measured+.7*bhat
                cp_log.append({'start':cp['start'],'end':t+1,'captured':captured,
                               'bytes':cp['size'],'success':True,'reason':cp['reason'],
                               'predicted_duration':cp['predicted_duration'],
                               'duration_error':t+1-cp['start']-cp['predicted_duration']})
                cp=None
        risk=max(0,int(math.floor(p))-committed)
        max_unprotected=max(max_unprotected,risk)
        if t>=recovery_until:
            observed_ticks+=1;risk_exceed+=int(risk>cfg.replay_budget)
        if keep_log and t%2==0:
            log.append({'t':t,'available':available,'processed':int(math.floor(p)),
                        'committed':committed,'queue':available-int(math.floor(p)),
                        'unprotected':risk,'rate_ewma':rate,'cp_active':int(cp is not None),
                        'bandwidth':bandwidth,'age':current_age})
        if committed==n:
            finish=t+1;break
    else:raise RuntimeError(f'Failed to drain {policy}, {trace["scenario"]}')
    assert np.isfinite(committed_at).all() and np.isfinite(first_ready).all()
    ingest_latency=committed_at-arr
    publish_wait=committed_at-first_ready
    # The durable prefix advances monotonically: exact log-record coverage.
    ranges=np.diff([0]+[int(k['captured']) for k in cp_log if k['success']])
    assert int(ranges.sum())==n and np.all(ranges>=0)
    miss=publish_wait>cfg.visible_budget
    assert math.isclose(success_incremental,cfg.bytes_per_update*n,abs_tol=1e-6)
    assert math.isclose(bytes_written,success_incremental+success_metadata+failed_written,abs_tol=1e-5)
    result={'split':trace['split'],'scenario':trace['scenario'],'policy':policy,
        'fixed':fixed,'seed':seed,'records':n,'finish':finish,
        'checkpoints':cp_count,'successful_checkpoints':success,'aborted_checkpoints':aborted,
        'checkpoint_mib':bytes_written/2**20,'checkpoint_busy_fraction':busy_ticks/finish,
        'checkpoint_duration_mean':float(np.mean(cp_durations)),
        'checkpoint_duration_p99':float(np.quantile(cp_durations,.99)),
        'ingest_latency_mean':float(np.mean(ingest_latency)),
        'ingest_latency_p95':float(np.quantile(ingest_latency,.95)),
        'ingest_latency_p99':float(np.quantile(ingest_latency,.99)),
        'publish_wait_mean':float(np.mean(publish_wait)),
        'publish_wait_p99':float(np.quantile(publish_wait,.99)),
        'publish_wait_max':float(publish_wait.max()),
        'publish_deadline_miss_count':int(miss.sum()),
        'publish_max_excess':float(max(0,publish_wait.max()-cfg.visible_budget)),
        'miss_with_rollback_count':int((miss&rollback_seen).sum()),
        'miss_without_rollback_count':int((miss&~rollback_seen).sum()),
        'publish_deadline_miss_fraction':float(np.mean(publish_wait>cfg.visible_budget)),
        'failures':len(lost_per_failure),'replay_records':replay_sum,
        'replay_per_failure':float(np.mean(lost_per_failure)) if lost_per_failure else 0.,
        'replay_max':max(lost_per_failure,default=0),
        'max_unprotected':max_unprotected,
        'risk_exceed_fraction':exposure_exceed/max(1,exposure_ticks),
        'exposure_ticks':exposure_ticks,'exposure_exceed_ticks':exposure_exceed,
        'active_failures':active_faults,'active_failures_over_budget':active_faults_exceed,
        'fault_over_budget_fraction':active_faults_exceed/active_faults if active_faults else float('nan'),
        'risk_exceed_fraction_legacy_clock':risk_exceed/max(1,observed_ticks),
        'successful_incremental_mib':success_incremental/2**20,
        'successful_metadata_mib':success_metadata/2**20,
        'failed_written_mib':failed_written/2**20,
        'duration_error_mean':float(np.mean(prediction_errors)),
        'duration_underpredict_fraction':float(np.mean(np.array(prediction_errors)>0)),
        'duration_underpredict_max':float(max(0,max(prediction_errors,default=0))),
        'blocked_any_ticks':blocked_any_ticks,'blocked_any_events':blocked_any_events,
        'infeasible_start_requests':infeasible_requests,
        **{f'blocked_{k}_ticks':v for k,v in blocked_ticks.items()},
        **{f'blocked_{k}_events':v for k,v in blocked_events.items()},
        'drain_seconds':max(0,finish-(math.ceil(arr[-1]))),
        'lost_output_records':0,'duplicate_effect_records':0}
    if keep_log:
        return result,pd.DataFrame(log),pd.DataFrame(cp_log),pd.DataFrame({
            'fid':trace['fid'],'arrival_replay_second':arr,'event_replay_second':trace['event'],
            'first_processed_second':first_ready,'committed_second':committed_at,
            'ingest_latency':ingest_latency,'publish_wait':publish_wait,
            'had_rollback':rollback_seen,'deadline_miss':miss})
    return result

def select_fixed(train:pd.DataFrame,cfg:Config):
    g=train.groupby('fixed').agg(cp_mib=('checkpoint_mib','mean'),
          wait_p99=('publish_wait_p99','mean'),risk=('risk_exceed_fraction','mean'))
    feasible=g[(g.wait_p99<=cfg.visible_budget)&(g.risk<=.01)]
    if len(feasible):return float(feasible.cp_mib.idxmin()),g
    # Explicit normalized constraint penalty, never silently use test outcomes.
    score=g.cp_mib/g.cp_mib.min()+10*np.maximum(g.wait_p99/cfg.visible_budget-1,0)+100*g.risk
    return float(score.idxmin()),g

def run_experiments(df,cfg:Config,quick=False):
    train_seeds=list(range(4 if quick else 8))
    test_seeds=list(range(100,106 if quick else 120))
    training=[]
    for scenario in ('normal','combined'):
        tr=make_trace(df,'train',scenario,cfg)
        for v in FIXED_INTERVALS:
            for seed in train_seeds:
                training.append(simulate(tr,'fixed',cfg,seed,v))
    td=pd.DataFrame(training);td.to_csv(ROOT/'results/training_runs.csv',index=False)
    chosen,g=select_fixed(td,cfg);g.to_csv(ROOT/'results/fixed_training_selection.csv')
    plan={'config':dataclasses.asdict(cfg),'fixed_candidates':FIXED_INTERVALS,
          'train_hours':'00:00-08:00','test_hours':'08:00-24:00',
          'training_seeds':train_seeds,'test_seeds':test_seeds,
          'selected_fixed_interval':chosen,'selection':'training only; P99 wait<=D and risk time<=1%; min checkpoint bytes'}
    (ROOT/'results/experiment_plan.json').write_text(json.dumps(plan,indent=2))
    print('TRAINED_FIXED',chosen,flush=True)
    runs=[]
    for scenario in ('normal','outage2h','outage6h','io_slow','combined'):
        tr=make_trace(df,'test',scenario,cfg)
        for pol in ('fixed','backlog','rate','count','adaptive','no_age','no_forecast','legacy'):
            for seed in test_seeds:
                runs.append(simulate(tr,pol,cfg,seed,chosen))
        print('DONE',scenario,flush=True)
    rd=pd.DataFrame(runs);rd.to_csv(ROOT/'results/test_runs.csv',index=False)
    summary=rd.groupby(['scenario','policy']).mean(numeric_only=True).reset_index()
    summary.to_csv(ROOT/'results/summary.csv',index=False)
    pairs=[]
    for scenario in rd.scenario.unique():
        a=rd[(rd.scenario==scenario)&(rd.policy=='adaptive')].set_index('seed')
        b=rd[(rd.scenario==scenario)&(rd.policy=='fixed')].set_index('seed')
        for met in ('checkpoint_mib','publish_wait_p99','replay_records','ingest_latency_p99'):
            diff=(a[met]-b[met]).to_numpy()
            rng=np.random.default_rng(20261108)
            boot=np.mean(rng.choice(diff,(3000,len(diff)),replace=True),axis=1)
            pairs.append({'scenario':scenario,'metric':met,'adaptive_mean':a[met].mean(),
                          'fixed_mean':b[met].mean(),'paired_difference':diff.mean(),
                          'ci_low':float(np.quantile(boot,.025)),
                          'ci_high':float(np.quantile(boot,.975)),
                          'relative_reduction_pct':100*(b[met].mean()-a[met].mean())/max(b[met].mean(),1e-9)})
    pd.DataFrame(pairs).to_csv(ROOT/'results/paired_comparison.csv',index=False)
    tr=make_trace(df,'test','combined',cfg)
    for pol in ('fixed','adaptive'):
        result,logs,cps,lat=simulate(tr,pol,cfg,100,chosen,True)
        logs.to_csv(ROOT/f'results/timeline_{pol}.csv',index=False)
        cps.to_csv(ROOT/f'results/checkpoints_{pol}.csv',index=False)
        lat.to_csv(ROOT/f'results/record_latency_{pol}.csv',index=False)
    # Fair diagnostic: test-side fixed grid is an oracle comparison, not tuning.
    oracle=[]
    for v in FIXED_INTERVALS:
        for scenario in ('normal','combined'):
            tr=make_trace(df,'test',scenario,cfg)
            for seed in test_seeds[:4]:oracle.append(simulate(tr,'fixed',cfg,seed,v))
    pd.DataFrame(oracle).to_csv(ROOT/'results/fixed_test_diagnostic.csv',index=False)
    controls=[]
    cc=dataclasses.replace(cfg,failure_mean=0.)
    for scenario in ('normal','outage2h','outage6h','io_slow','combined'):
        tt=make_trace(df,'test',scenario,cc)
        for pol in ('fixed','adaptive'):
            controls.append(simulate(tt,pol,cc,100,chosen))
    pd.DataFrame(controls).to_csv(ROOT/'results/no_failure_controls.csv',index=False)
    return chosen

def sensitivity(df,cfg,chosen):
    runs=[]; tuning_rows=[]
    cases=[('failure_mean',0.),('failure_mean',1800.),('failure_mean',450.),
           ('bandwidth',32768.),('bandwidth',131072.),
           ('processing_penalty',0.),('processing_penalty',.7),
           ('visible_budget',40.),('visible_budget',90.),
           ('replay_budget',400.),('replay_budget',900.),
           ('state_bytes_per_ship',2048.),('state_bytes_per_ship',8192.),
           ('guard_sigma',0.),('guard_sigma',1.5)]
    for field,value in cases:
        cc=dataclasses.replace(cfg,**{field:value});tr=make_trace(df,'test','combined',cc)
        # Re-select the static comparator on training data for this configuration.
        # The adaptive policy coefficients remain unchanged.
        tune=[]
        for ss in ('normal','combined'):
            tt=make_trace(df,'train',ss,cc)
            for vv in FIXED_INTERVALS:
                for sd in range(4):tune.append(simulate(tt,'fixed',cc,sd,vv))
        local_fixed,_=select_fixed(pd.DataFrame(tune),cc)
        for z in tune:
            z.update(sensitivity_parameter=field,sensitivity_value=value)
            tuning_rows.append(z)
        for pol in ('fixed','adaptive'):
            for seed in range(100,106):
                out=simulate(tr,pol,cc,seed,local_fixed);out.update(sensitivity_parameter=field,sensitivity_value=value)
                runs.append(out)
        print('SENSITIVITY',field,value,'trained fixed',local_fixed,flush=True)
    pd.DataFrame(runs).to_csv(ROOT/'results/sensitivity_runs.csv',index=False)
    pd.DataFrame(tuning_rows).to_csv(ROOT/'results/sensitivity_training_runs.csv',index=False)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--quick',action='store_true')
    ap.add_argument('--prepare-only',action='store_true');ap.add_argument('--skip-sensitivity',action='store_true')
    args=ap.parse_args();cfg=Config()
    csv=ROOT/'data/ais_records.csv'
    df=pd.read_csv(csv,parse_dates=['ts']) if csv.exists() else prepare_data()
    if args.prepare_only:return
    chosen=run_experiments(df,cfg,args.quick)
    if not args.skip_sensitivity:sensitivity(df,cfg,chosen)
    print('FINISHED',flush=True)

if __name__=='__main__':main()
