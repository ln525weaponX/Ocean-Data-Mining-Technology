"""Re-download the immutable original, verify SHA256 and rebuild the CSV extract."""
from study import prepare_data
if __name__=='__main__':
    df=prepare_data()
    print(f'Extracted {len(df):,} rows and {df.MMSI.nunique()} vessels')
