"""Revise the supplied V1 draft while retaining course sections 1 through 6."""
from __future__ import annotations
import copy,io,json,re,subprocess
from pathlib import Path
import numpy as np
import pandas as pd
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from study import ROOT

def tab(headers,rows):
    return '\n'.join(['|'+'|'.join(headers)+'|','|'+'|'.join(['---']*len(headers))+'|']+
                     ['|'+'|'.join(map(str,row))+'|' for row in rows])+'\n'

def main():
    rep=ROOT/'report';res=ROOT/'results';rep.mkdir(exist_ok=True)
    source=rep/'source_v1.docx'
    if not source.exists():source.write_bytes((ROOT.parent/'upload/检查点调度模型与公开AIS验证V1.docx').read_bytes())
    runs=pd.read_csv(res/'test_runs.csv');g=runs.groupby(['scenario','policy']).mean(numeric_only=True)
    adaptive=runs[runs.policy=='adaptive'];tx=json.loads((res/'transaction_check_summary.json').read_text())
    plan=json.loads((res/'experiment_plan.json').read_text());sens=pd.read_csv(res/'sensitivity_runs.csv')
    diff=pd.read_csv(res/'paired_comparison.csv').set_index(['scenario','metric'])
    names={'normal':'正常输入','outage2h':'两小时断链补传','outage6h':'六小时断链补传','io_slow':'存储降速','combined':'断链与存储降速叠加'}
    reductions={s:100*(1-g.loc[(s,'adaptive'),'checkpoint_mib']/g.loc[(s,'fixed'),'checkpoint_mib']) for s in names}
    total_late=int(adaptive.publish_deadline_miss_count.sum());total_obs=int(adaptive.records.sum())
    c=[]
    c.append(f'''# 7 研究简介与证据范围

本报告在课程学习和AI辅助分析基础上，建立预算约束的在线检查点时间调度模型。固定计算图与原子提交协议后，调度器根据未保护处理量、待提交结果年龄，以及随候选等待时间增长的快照上传量，决定何时请求检查点。性能目标是减少实际检查点写入，并用发布等待与重算量预算约束资源节省的代价。

本版统一使用V2增量上传模型及在线控制程序重跑实验。公开AIS样本共84,702条记录、100个不同MMSI；前8小时用于校准，后16小时用于留出验证。主实验包含5种场景、8种策略及20个共同故障种子，共800次运行。固定对照仅用校准数据选出，间隔为{plan['selected_fixed_interval']:g}回放秒。V2在正常场景减少检查点写入{reductions['normal']:.2f}%，在叠加压力场景减少{reductions['combined']:.2f}%；100次自适应运行均达到设定的P99与暴露率验收条件。

验证分为公开轨迹驱动的离散时间模拟和实际SQLite事务故障回放。模拟中的到达时间、成本、带宽与故障是显式实验条件，时间单位为回放秒；SQLite检验单数据库原子提交边界。本报告分别报告两类证据，不将仿真数字作为实测Flink集群性能。

## 7.1 研究定位

本研究调节既定计算图上的全局检查点触发时机，不改变算子位置、事件时间窗口、水位线或事务提交协议。已有周期优化和动态调度研究，Flink 1.19也支持积压期间使用更长间隔[18]。本例的切入点是将重算预算、可见等待预算和候选快照增长共同纳入可计算的在线决策，并在断链补传压力下检验其权衡。

源端通信中断与计算进程故障分别注入。前者改变记录抵达日志的时间，后者使处理进度回退；两者不能合并为同一种故障。调度器不读取未来到达序列、未来故障时刻或未来存储扰动。

# 8 修订后的在线调度模型

## 8.1 系统边界与变量

可重放日志连接一个有状态处理任务和一个原子提交结果域。一次检查点捕获已完整处理的日志前缀，持久化成功后提交该前缀的结果。工作进程故障时恢复到最近成功提交的前缀。只允许一个在途检查点；保存期间处理继续，但可因I/O竞争降低能力。模型将持久化完成与结果原子可见合并为同一时刻；真实连接器的额外提交延迟应在集群实验中另行测量。
''')
    c.append(tab(['符号','含义','单位'],[
        ['$A_t$ 与 $p_t$','已进入日志的累计量与当前处理进度','条'],
        ['$c_t$','最近成功提交的输入前缀','条'],
        ['$q_t$ 与 $u_t$','输入积压与已处理但未保护的记录数','条'],
        ['$a_t$','最早待提交记录自首次处理完成后的年龄','回放秒'],
        ['$S_t^{\\mathrm{up}}$','一次检查点实际上传量的代理','字节'],
        ['$F_t$','完整状态及恢复读取量的代理','字节'],
        ['$\\widehat r_t^+$ 与 $\\widehat B_t$','未保护量增长速率与有效写带宽的估计','条每秒 与 字节每秒'],
        ['$D$ 与 $R$','发布等待预算与重算记录量预算','回放秒 与 条'],
        ['$h$ 与 $H_t$','候选等待时长与局部最大可行整数等待','回放秒']]))
    c.append((rep/'model_core.md').read_text(encoding='utf-8'))
    c.append(tab(['项目','实际值'],[
        ['总记录与不同MMSI','84,702条 与100个'],['原始时间范围','2017年7月5日00:00:03至23:59:58'],
        ['校准与留出记录','前8小时22,550条 后16小时62,152条'],['分钟记录数中位数与最大值','56 与153'],
        ['SOG与COG缺失','3条 与500条'],['时间 MMSI SOG COG属性重复的后续行','537条 保留不同fid输入行']]))
    c.append('''
只使用相对时间，不推定未标注的时区。保留fid、时间、MMSI等非几何字段；缺失航速航向不影响按时间回放。本例不以MMSI或属性重复作为交付去重条件。来源、提取哈希与环境版本随项目提供。

![图1 公开AIS负载与受控补传](../figures/01_public_trace.png){width=6.2in}

## 9.2 参数与受控扰动

原始观测间隔以12倍速回放。源数据不包含真实日志到达时间、运行故障或检查点成本，本例在相对观测时间上设置输入延迟、故障和硬件代理。下表中的时间均为回放秒。
''')
    c.append(tab(['参数','默认设置','用途'],[
        ['正常处理能力 与保存能力损失','48条每秒 与35%','处理与I/O竞争'],
        ['固定准备耗时','1.5秒','保存准备阶段'],['固定元数据 与每条增量','16 KiB 与128字节','上传模型'],
        ['每船完整状态','4 KiB','只用于恢复读取'],['写带宽 与恢复带宽','64 KiB每秒 与256 KiB每秒','分别计量'],
        ['恢复固定暂停','8秒','重启代理'],['指数故障间隔均值','900秒','独立压力假设'],
        ['发布等待 与重算预算','60秒 与600条','设计预算'],['最小间隔 暂停 最大间隔','3秒 1秒 120秒','协调约束'],
        ['速率系数 带宽系数 波动系数','0.08 0.3 0.75','在线估计']]))
    c.append(rf'''
场景为正常输入、两小时断链补传、六小时断链补传、存储降速、两小时断链叠加存储降速。两小时与六小时指原始事件时域。断链起点在该分段时域28%处，恢复后按事件进度6倍速度释放扣留记录，同时实时输入继续进入；按到达时间与fid稳定排序。存储在时域18%至36%、65%至79%降为正常带宽的四分之一。

故障使工作进程回滚并中止在途检查点。控制器与监控历史在故障中保留，本轮没有模拟协调器自身崩溃。恢复使用已提交前缀的完整状态代理。故障时刻在主实验各策略间共享；与未保护量相关的故障后果由各自运行状态决定。

## 9.3 基线 校准与诊断

固定间隔候选为5、10、15、20、30、45、60、90、120秒。仅用前8小时的正常与叠加场景、种子0至7，共144次校准运行，筛选平均P99不超过60且平均暴露率不超过1%的候选，再选平均写入量最小者。本次选出15秒；若没有可行候选，程序采用显式约束惩罚。

留出实验使用种子100至119。8种策略为固定间隔、积压时延长间隔、仅按速率、仅按数量、V2自适应、去掉年龄保护、去掉保存余量、V1瞬时触发参考。所有策略使用相同V2增量上传模型；V1参考只保留原瞬时触发规则，不恢复封顶成本。积压策略是两档间隔思想的简化实现，不代表完整Flink连接器；本轮也未直接复现Ca-Stream完整实现。

去掉保存余量时，重算约束仅保留触发前增长$u_t+\widehat r_t^+h\le R$，年龄约束仍包含预计保存耗时。这样可单独观察保存期间新增未保护量的作用。另有72次留出固定间隔扫描，只用于前沿诊断；10次无故障对照用于检查故障对尾部等待的影响。

敏感性覆盖15组参数变化，每组在校准数据上重新选择固定对照，V2估计系数保持相应预设，共{len(sens)}次测试运行及{len(pd.read_csv(res/'sensitivity_training_runs.csv'))}次校准运行。除了故障频率、带宽、能力损失与预算，也改变每船完整状态和波动系数，以区分恢复成本与上传模型的作用。

# 10 留出结果与解释

## 10.1 资源与时效权衡

下表为20次运行的均值，箭头表示固定15秒至V2自适应。P99先逐次计算再求均值，未将多次运行合并计算分位数。暴露率在统一的故障前采样时域内统计。
''')
    rows=[]
    for s,label in names.items():
        f=g.loc[(s,'fixed')];a=g.loc[(s,'adaptive')]
        rows.append([label,f'{f.checkpoint_mib:.2f} → {a.checkpoint_mib:.2f}',f'{f.publish_wait_p99:.2f} → {a.publish_wait_p99:.2f}',f'{100*f.risk_exceed_fraction:.3f} → {100*a.risk_exceed_fraction:.3f}',f'{f.replay_per_failure:.1f} → {a.replay_per_failure:.1f}'])
    c.append(tab(['场景','写入 MiB','等待P99 秒','暴露率 %','每故障重算 条'],rows))
    c.append(f'''
正常场景写入减少{reductions['normal']:.2f}%，叠加压力减少{reductions['combined']:.2f}%，六小时补传减少{reductions['outage6h']:.2f}%。100次自适应主运行逐次达到两项验收条件。固定对照在正常与仅存储降速场景也达到条件；在断链场景，其暴露率超出1%目标。

V2通过更长的发布等待及更大的故障重算量换取较少检查点写入。业务如果需要更短等待或更少重算，应收紧相应预算并重新评价。某一类写入减少不能直接换算为总CPU或总存储成本的相同比例下降。

![图2 V2资源 时效与恢复代价](../figures/02_tradeoffs.png){{width=6.2in}}
''')
    ci=[]
    for s in ['normal','combined']:
        z=diff.loc[(s,'checkpoint_mib')];ci.append([names[s],f'{z.paired_difference:.4f}',f'[{z.ci_low:.4f}, {z.ci_high:.4f}]'])
    c.append(tab(['场景','写入配对差 MiB','95%自助法区间'],ci))
    c.append('''
区间以共同故障种子的配对差作3000次重采样，反映本次故障随机性下的波动。它不表示跨海域、跨硬件或跨日期的总体区间。

![图3 固定间隔前沿与在线策略](../figures/03_frontier.png){width=6.2in}

前沿图使用4个测试种子扫描固定间隔，仅作事后诊断，不参与调参。比较时必须同时考虑暴露率与等待约束，不能只用写入量给策略排名。

## 10.2 写入成本分解

下表为正常场景20次运行的均值。线性增量在所有成功检查点中总计为输入记录数乘128字节；固定元数据随成功检查点次数变化，失败写入单独计入。
''')
    decomp=[]
    for m,label in [('successful_incremental_mib','成功增量'),('successful_metadata_mib','成功固定元数据'),('failed_written_mib','失败尝试已写字节'),('checkpoint_mib','合计')]:
        decomp.append([label,f"{g.loc[('normal','fixed'),m]:.4f}",f"{g.loc[('normal','adaptive'),m]:.4f}"])
    c.append(tab(['组成','固定15秒 MiB','V2自适应 MiB'],decomp))
    normal_fixed=g.loc[('normal','fixed')];normal_ad=g.loc[('normal','adaptive')]
    saved=normal_fixed.checkpoint_mib-normal_ad.checkpoint_mib
    meta_saved=normal_fixed.successful_metadata_mib-normal_ad.successful_metadata_mib
    c.append(f'''
正常场景固定元数据减少{meta_saved:.4f} MiB，失败尝试写入增加{meta_saved-saved:.4f} MiB，抵消部分收益后净节省{saved:.4f} MiB。单个较大检查点的元数据占比小，不等于它对策略总写入差异的贡献小。该分解明确了本例资源收益的主要机制。

![图4 成功增量 固定元数据与失败写入](../figures/07_cost_decomposition.png){{width=6.0in}}

## 10.3 尾部等待与调度阻塞

下表的最大等待为20次运行中最坏单条值；超时数、阻塞周期与事件数均为20次运行累计。阻塞周期的单位是1秒控制周期，事件为连续阻塞段，不将同一段逐秒重复计为多个事件。
''')
    tail=[]
    for s,label in names.items():
        z=adaptive[adaptive.scenario==s]
        tail.append([label,f'{z.publish_wait_max.max():.0f}',int(z.publish_deadline_miss_count.sum()),int(z.blocked_any_ticks.sum()),int(z.blocked_any_events.sum())])
    c.append(tab(['场景','最大等待 秒','超时记录观测','阻塞周期','阻塞事件'],tail))
    b=[]
    for key,label in [('inflight','在途检查点'),('pause','完成后最小暂停'),('interval','最小启动间隔'),('recovery','恢复暂停')]:
        b.append([label,int(adaptive[f'blocked_{key}_ticks'].sum()),int(adaptive[f'blocked_{key}_events'].sum())])
    c.append(tab(['阻塞原因','100次运行累计周期','累计连续事件'],b))
    c.append(f'''
100次运行累计{total_late}条超时记录观测，占{total_obs:,}条记录观测的{100*total_late/total_obs:.5f}%。这是同一留出样本多次回放的记录观测数，不是额外采集的不同AIS记录数。所有这些超时记录均曾在已处理但未提交阶段经历回滚；这说明与故障恢复有关联，单凭此标记不能区分全部间接影响。

无故障对照的五种场景均无超时，最坏单条等待为58或59秒。该对照与带故障结果共同表明：控制器预测保护、实际最大等待与P99验收是不同层次的量。P99靠近预算符合成本优先策略的预期，不能单独作为算法优势的证据。

![图5 最大等待与超时记录审计](../figures/06_tail_audit.png){{width=6.2in}}

## 10.4 暴露率与故障采样

下表同时给出暴露时刻计数与故障前命中计数。暴露率在20次运行中按总暴露秒数加权；故障命中比例以累计实际故障为分母。低频故障的有限样本可能没有命中过阈值状态。
''')
    riskrows=[]
    for s,label in names.items():
        z=adaptive[adaptive.scenario==s];nr=int(z.active_failures.sum());over=int(z.active_failures_over_budget.sum())
        riskrows.append([label,f'{100*z.exposure_exceed_ticks.sum()/z.exposure_ticks.sum():.4f}%',f'{over}/{nr}',f'{100*over/nr:.2f}%' if nr else '未定义'])
    c.append(tab(['场景','加权暴露率','故障超限次数 与总数','故障命中比例'],riskrows))
    c.append('''
暴露率的分项秒数、故障次数与全部逐次结果均提供CSV。当前故障命中数有限，不能把0次命中写为真实故障超限概率为0。负载相关故障需要另设强度模型并独立检验，本轮结果仅对应声明的恒定强度假设。

## 10.5 V1规则参照与消融

下表采用同一V2上传成本与统计口径比较触发规则，列出每场景20次运行的均值。V1参照在主自适应场景本就未触发封顶，故写入与原版对应结果一致；暴露率改用统一故障前时点，不应与旧版时钟口径直接混算。
''')
    version=[]
    for s in ['normal','combined']:
        old=g.loc[(s,'legacy')];new=g.loc[(s,'adaptive')]
        version.append([names[s],f'{old.checkpoint_mib:.3f} → {new.checkpoint_mib:.3f}',f'{old.publish_wait_p99:.2f} → {new.publish_wait_p99:.2f}',f'{100*old.risk_exceed_fraction:.4f} → {100*new.risk_exceed_fraction:.4f}'])
    c.append(tab(['场景','V1规则至V2 写入MiB','等待P99 秒','暴露率 %'],version))
    c.append('''
V2通过候选快照增长和提前一控制周期请求，使推导与实现一致，部分场景以额外写入换取较低暴露率。故障下超时记录数并未在所有场景都减少，应结合尾部表评价，不能声称全面优于前一规则。

叠加场景的消融如下。移除年龄保护主要影响低负载可见性；移除保存余量主要影响快照完成前继续增长的未保护量。
''')
    ab=[]
    for p,l in [('adaptive','完整V2'),('no_age','去掉年龄保护'),('no_forecast','去掉保存余量'),('rate','仅按速率'),('count','仅按数量')]:
        z=g.loc[('combined',p)];ab.append([l,f'{z.checkpoint_mib:.3f}',f'{z.publish_wait_p99:.2f}',f'{100*z.risk_exceed_fraction:.3f}%'])
    c.append(tab(['方案','写入 MiB','等待P99 秒','暴露率'],ab))
    c.append('''
## 10.6 在线过程 敏感性与端到端延迟

![图6 同一故障轨迹下的在线过程](../figures/04_online_timeline.png){width=5.7in}

![图7 对重新校准固定基线的敏感性](../figures/05_sensitivity.png){width=6.2in}

敏感性图展示固定对照重新校准后的写入节省及V2暴露率。每船状态参数只通过恢复阶段起作用，波动系数用于检验启发式余量。全部参数和逐次结果随项目提供，不依据留出结果重新选择主实验控制系数。
''')
    for s in ['combined','outage6h']:
        zf=g.loc[(s,'fixed')];za=g.loc[(s,'adaptive')];dd=diff.loc[(s,'ingest_latency_p99')]
        c.append(f"{names[s]}的日志到可见P99均值为{zf.ingest_latency_p99:.2f}至{za.ingest_latency_p99:.2f}秒，配对差95%区间为[{dd.ci_low:.2f}, {dd.ci_high:.2f}]。该指标还包含输入排队与恢复，需与首次处理完成后的发布等待分开评价。\n")
    c.append(f'''
# 11 原子提交与可行性判断

## 11.1 实际事务故障回放

使用V2固定与自适应策略产生的成功检查点边界，对叠加场景按到达顺序排列的前8,000条公开输入执行SQLite事务[19]。每批同时更新输入游标、按原始事件时间10分钟窗口累加的报文数、窗口船舶集合与审计日志。报文计数使用加法，审计fid没有唯一约束，避免用审计去重掩盖重复提交。

故障分别注入事务前、结果更新后游标更新前、游标更新后提交前、提交成功但确认丢失后。关闭连接并重开模拟工作进程中断，不涉及操作系统断电或介质损坏。
''')
    c.append(tab(['核验项目','结果'],[
        ['正向原子事务',f"{tx['atomic_trials']}次 每次8,000条"],['注入异常',tx['injected_crashes']],
        ['提交成功但确认丢失',tx['commit_ack_losses']],['缺失与重复生效',f"{tx['missing_effects']} 与 {tx['duplicate_effects']}"],
        ['窗口报文数与船舶集合','全部匹配批量真值'],
        ['先提交结果后保存游标',f"累计{tx['negative_controls']['effect_first']['duplicate_effects']}次重复效果"],
        ['先保存游标后提交结果',f"累计{tx['negative_controls']['progress_first']['missing_effects']}条缺失效果"]]))
    c.append('''
两个反例各含6次运行，数值为跨运行累计。正向试验支持不同调度边界在单数据库原子事务下获得同一批量真值。它没有代替Flink全局屏障恢复、跨数据库事务、协调器失效或外部通知投递试验。

## 11.2 结论与下一阶段

本次公开轨迹回放支持预算约束在线检查点调度的研究可行性。修订模型区分增量上传与完整恢复量，把等待期间快照增长纳入局部决策，并通过成本分解解释资源收益。验收与尾部审计共同展示P99合格、少量单条超时及故障重算之间的实际关系。

证据范围为一天、一个区域、100个MMSI的样本；到达时间、带宽、状态字节与故障分布均为声明的实验条件。控制器保留监控历史，计算单条记录工作量取1，本轮未实现分布式Flink或Ca-Stream完整对照。局部整数搜索有精确可行性解，整个在线策略的随机全局最优性仍是独立问题。

下一阶段保持业务口径与公共轨迹不变，在Flink和事务下游中测量真实增量上传、对齐时间、提交可见时间及恢复追赶量，以实测函数替换代理。随后扩展多日、多站点和负载相关故障，评价预算达标率与总资源成本的泛化。外部提交完成时刻也应独立计量。

## 11.3 复现说明

修订项目包含完整非几何字段CSV、固定来源哈希、V2模型、实际事务核验、全部运行明细、图像及已执行Notebook。解压后保持data、src、results和figures目录。安装requirements.txt后依次运行：

```text
python src/study.py
python src/transaction_check.py
python src/make_figures.py
python src/build_notebook.py
python src/verify_results.py
```

Notebook位于解压根目录。重建Word报告另需Pandoc及支持中文和数学的字体，运行python src/revise_report.py。原始GeoPackage可按固定地址重新下载，字段CSV已附，无需重新获取即可复现主要结果。历史V1审计不参与V2校准。

# 参考资料

[1] 海洋大数据课程材料学习记录 20261107 含第七讲更新。课程第五部分与配套学习材料。

[2] Apache Flink. Fault Tolerance. https://nightlies.apache.org/flink/flink-docs-stable/docs/learn-flink/fault_tolerance/

[3] Apache Flink. Event Time. https://nightlies.apache.org/flink/flink-docs-stable/docs/concepts/time/

[4] Akidau T, Bradshaw R, Chambers C, et al. The Dataflow Model A Practical Approach to Balancing Correctness Latency and Cost in Massive Scale Unbounded Out of Order Data Processing. PVLDB, 2015, 8:1792–1803. https://www.vldb.org/pvldb/vol8/p1792-Akidau.pdf

[5] Apache Kafka. Design Using Transactions. https://kafka.apache.org/design/

[6] Apache Flink. Checkpointing. https://nightlies.apache.org/flink/flink-docs-stable/docs/dev/datastream/fault-tolerance/checkpointing/

[7] Apache Spark. Structured Streaming Programming Guide. https://spark.apache.org/docs/latest/streaming/index.html

[8] Apache Beam. Programming Guide. https://beam.apache.org/documentation/programming-guide/

[9] Chandy K M, Lamport L. Distributed Snapshots Determining Global States of Distributed Systems. ACM TOCS, 1985, 3:63–75. https://doi.org/10.1145/214451.214456

[10] Apache Flink. Checkpointing under Backpressure. https://nightlies.apache.org/flink/flink-docs-stable/docs/ops/state/checkpointing_under_backpressure/

[11] Apache Flink. Monitoring Back Pressure. https://nightlies.apache.org/flink/flink-docs-stable/docs/ops/monitoring/back_pressure/

[12] Apache Flink. Tuning Checkpoints and Large State. https://nightlies.apache.org/flink/flink-docs-stable/docs/ops/state/large_state_tuning/

[13] Apache Flink. An Overview of End to End Exactly Once Processing in Apache Flink with Apache Kafka Too. 2018. https://flink.apache.org/2018/02/28/an-overview-of-end-to-end-exactly-once-processing-in-apache-flink-with-apache-kafka-too/

[14] Jayasekara S, Harwood A, Karunasekera S. A utilization model for optimization of checkpoint intervals in distributed stream processing systems. Future Generation Computer Systems, 2020, 110:68–79. https://doi.org/10.1016/j.future.2020.04.019

[15] Sun D, Peng J, Zhu T, Kua J, Gao S, Buyya R. Toward High Availability Distributed Stream Computing Systems via Checkpoint Adaptation. Concurrency and Computation Practice and Experience, 2025, 37:e70171. https://doi.org/10.1002/cpe.70171

[16] Young J W. A first order approximation to the optimum checkpoint interval. Communications of the ACM, 1974, 17:530–531. https://doi.org/10.1145/361147.361115

[17] MovingPandas Examples. Example datasets README and pinned ais.gpkg. https://github.com/movingpandas/movingpandas-examples/blob/main/data/README.md

[18] Apache Flink. Announcing the Release of Apache Flink 1.19. 2024年3月18日. https://flink.apache.org/2024/03/18/announcing-the-release-of-apache-flink-1.19/

[19] SQLite. Atomic Commit In SQLite and Transaction. https://www.sqlite.org/atomiccommit.html 及 https://www.sqlite.org/lang_transaction.html

[20] Wolff R W. Poisson Arrivals See Time Averages. Operations Research, 1982, 30:223–231. https://doi.org/10.1287/opre.30.2.223

[21] Apache Flink. Improving speed and stability of checkpointing with generic log based incremental checkpoints. 2022年5月30日. https://flink.apache.org/2022/05/30/improving-speed-and-stability-of-checkpointing-with-generic-log-based-incremental-checkpoints/
''')
    md='\n\n'.join(c)
    md=md.replace(r'\\varepsilon',r'\varepsilon').replace(r'\\mu',r'\mu')
    # Equation 8's prose is kept outside math to avoid Chinese glyphs inside OMML.
    md=md.replace(r'\text{式7两项预测约束成立}',r'g_D(h)\le0,\ g_R(h)\le0')
    md=md.replace('对非负$M_t$，定义满足式7的整数集合及其最大值：',
                  '将式7两项约束的左侧减去各自预算，记为$g_D(h)$与$g_R(h)$。对非负$M_t$，定义可行整数集合及其最大值：')
    (rep/'revised_research_sections.md').write_text(md,encoding='utf-8')
    default=rep/'pandoc_reference.docx';default.write_bytes(subprocess.check_output(['pandoc','--print-default-data-file','reference.docx']))
    generated=rep/'research_sections.docx'
    subprocess.run(['pandoc',str(rep/'revised_research_sections.md'),'-o',str(generated),
                    '--from=markdown+tex_math_dollars','--reference-doc='+str(default),
                    '--resource-path='+str(rep)],check=True)
    doc=Document(source);new=Document(generated)
    cut=next(p._p for p in doc.paragraphs if p.text.startswith('7 研究简介'))
    body=doc.element.body;start=list(body).index(cut)
    for el in list(body)[start:]:
        if el.tag!=qn('w:sectPr'):body.remove(el)
    # Normalize duplicated title blocks while retaining the user's course text.
    pp=doc.paragraphs
    pp[0].text='检查点调度模型与公开 AIS 数据验证';pp[0].style=doc.styles['Title']
    pp[1].text='流式处理基础与预算约束在线时间调度';pp[1].style=doc.styles['Subtitle']
    pp[2].text='2026年11月9日'
    for p in pp[3:6]:p._p.getparent().remove(p._p)
    intro=OxmlElement('w:p');pp[2]._p.addnext(intro)
    from docx.text.paragraph import Paragraph
    ip=Paragraph(intro,doc._body)
    ip.add_run(f'本报告先梳理流式处理与恰好一次保障，再构建检查点在线调度模型，并以公开AIS轨迹和事务故障回放验证。修订模型在正常与叠加压力场景分别减少检查点写入{reductions["normal"]:.2f}%和{reductions["combined"]:.2f}%；性能证据来自明确参数下的仿真，事务正确性证据限定于单数据库原子边界。')
    citation_map={10:7,11:8,12:9,13:10,14:11,15:12,16:13,17:14,18:15,19:16}
    def renumber(m):
        nums=[int(x) for x in m.group(1).split(',')]
        return '['+','.join(str(citation_map.get(x,x)) for x in nums)+']'
    for p in doc.paragraphs:
        for r in p.runs:
            r.text=re.sub(r'\[(\d+(?:,\d+)*)\]',renumber,r.text)
    # Preserve relationship identities for the original course material; map new
    # images through python-docx so media part names cannot collide.
    rmap={}
    for el in list(new.element.body):
        if el.tag==qn('w:sectPr'):continue
        cp=copy.deepcopy(el)
        for node in cp.iter():
            for attr in (qn('r:embed'),qn('r:id'),qn('r:link')):
                rid=node.get(attr)
                if not rid:continue
                if rid not in rmap:
                    rel=new.part.rels[rid]
                    if rel.reltype==RT.IMAGE:rmap[rid]=doc.part.get_or_add_image(io.BytesIO(rel.target_part.blob))[0]
                    else:rmap[rid]=doc.part.relate_to(rel.target_ref if rel.is_external else rel.target_part,rel.reltype,rel.is_external)
                node.set(attr,rmap[rid])
        body.insert(len(body)-1,cp)
    existing={s.style_id for s in doc.styles}
    for st in new.styles:
        if st.style_id not in existing:doc.styles.element.append(copy.deepcopy(st.element))
    for root in (doc.element,doc.styles.element):
        for x in root.xpath('.//w:pBdr | .//w:bookmarkStart | .//w:bookmarkEnd'):
            x.getparent().remove(x)
    # Ensure the retained course headings are real Word headings.
    for p in doc.paragraphs:
        if re.match(r'^\d+\.\d+\s*\S',p.text):p.style=doc.styles['Heading 2']
        elif re.match(r'^\d+\s+\S',p.text):p.style=doc.styles['Heading 1']
    for st in doc.styles:
        if st.type==1:
            st.font.name='Noto Serif CJK SC';st.font.color.rgb=RGBColor(0,0,0)
            fonts=st.element.get_or_add_rPr().get_or_add_rFonts()
            for a in ('ascii','hAnsi','eastAsia'):fonts.set(qn('w:'+a),'Noto Serif CJK SC')
            for a in ('asciiTheme','hAnsiTheme','eastAsiaTheme'):fonts.attrib.pop(qn('w:'+a),None)
    for st in doc.styles:
        if st.name.lower() in ('normal','body text','first paragraph','compact'):
            st.font.size=Pt(10.5);st.paragraph_format.line_spacing=1.25;st.paragraph_format.space_after=Pt(6)
        if st.name.lower() in ('heading 1','heading 2','title','subtitle'):
            size={'heading 1':15,'heading 2':12,'title':20,'subtitle':12}[st.name.lower()]
            st.font.size=Pt(size);st.paragraph_format.space_before=Pt(11);st.paragraph_format.space_after=Pt(7)
            st.paragraph_format.keep_with_next=True
    in_references=False
    for pi,p in enumerate(doc.paragraphs):
        if p.text=='参考资料':in_references=True
        ishead=p.style.name.lower().startswith('heading')
        if p.style.name not in ('Title','Subtitle'):
            p.paragraph_format.line_spacing=1.18
            p.paragraph_format.space_before=Pt(10 if ishead else 0)
            p.paragraph_format.space_after=Pt(6)
        for r in p.runs:
            r.font.name='Noto Serif CJK SC';r._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC')
            r.font.color.rgb=RGBColor(0,0,0)
            if p.style.name not in ('Title','Subtitle'):
                r.font.size=Pt(15 if p.style.name.lower()=='heading 1' else 12 if ishead else 10.5)
                if in_references and not ishead:r.font.size=Pt(9.5)
        if in_references and not ishead:
            p.paragraph_format.line_spacing=1.12;p.paragraph_format.space_after=Pt(4)
        if pi+1<len(doc.paragraphs) and doc.paragraphs[pi+1]._p.xpath('.//m:oMathPara'):
            if p.text and not p._p.xpath('.//m:oMathPara'):p.paragraph_format.keep_with_next=True
        if p.style.name in ('Image Caption','Caption'):
            p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=False
        if p._p.xpath('.//w:drawing'):
            p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
    for tb in doc.tables:
        tb.autofit=False;tb.alignment=WD_TABLE_ALIGNMENT.CENTER
        count=len(tb.columns)
        widths={2:[2.1,4.7],3:[1.65,3.65,1.5],4:[2.0,1.6,1.7,1.5],5:[1.6,1.3,1.4,1.25,1.25]}.get(count,[6.8/count]*count)
        for x in tb._tbl.tblPr.findall(qn('w:tblBorders')):tb._tbl.tblPr.remove(x)
        borders=OxmlElement('w:tblBorders')
        for side in ['top','left','bottom','right','insideH','insideV']:
            x=OxmlElement('w:'+side);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');borders.append(x)
        tb._tbl.tblPr.append(borders)
        for ri,row in enumerate(tb.rows):
            if ri==0 and row._tr.get_or_add_trPr().find(qn('w:tblHeader')) is None:row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
            for ci,cell in enumerate(row.cells):
                cell.width=Inches(widths[ci]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                pr=cell._tc.get_or_add_tcPr()
                for old in pr.findall(qn('w:shd')):pr.remove(old)
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'DCE8EF' if ri==0 else 'F5F8FA' if ri%2==0 else 'FFFFFF');pr.append(sh)
                for p in cell.paragraphs:
                    p.paragraph_format.line_spacing=1.15;p.paragraph_format.space_before=Pt(4);p.paragraph_format.space_after=Pt(4)
                    for r in p.runs:
                        r.font.name='Noto Serif CJK SC';r._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'),'Noto Serif CJK SC')
                        r.font.size=Pt(9.5);r.font.color.rgb=RGBColor(0,0,0)
                        if ri==0:r.bold=True
        for col,w in zip(tb.columns,widths):col.width=Inches(w)
    for sec in doc.sections:
        sec.page_width=Inches(8.5);sec.page_height=Inches(11)
        sec.left_margin=sec.right_margin=sec.top_margin=sec.bottom_margin=Inches(.78)
    mp=doc.settings.element.find(qn('m:mathPr'))
    if mp is None:mp=OxmlElement('m:mathPr');doc.settings.element.append(mp)
    mf=mp.find(qn('m:mathFont'))
    if mf is None:mf=OxmlElement('m:mathFont');mp.append(mf)
    mf.set(qn('m:val'),'XITS Math')
    used={v for el in doc.element.iter() for k,v in el.attrib.items() if k in (qn('r:embed'),qn('r:id'),qn('r:link'))}
    for rid,rel in list(doc.part.rels.items()):
        if rel.reltype==RT.IMAGE and rid not in used:doc.part.drop_rel(rid)
    output=rep/'检查点调度模型与公开AIS验证V2.docx';doc.save(output)
    print(output)

if __name__=='__main__':main()
