from pathlib import Path
import json,hashlib,zipfile
import numpy as np,pandas as pd
from study import ROOT,Config,latest_wait,future_duration

def main():
    checks={}
    meta=json.loads((ROOT/'provenance/download.json').read_text())
    assert hashlib.sha256((ROOT/'data/ais_records.csv').read_bytes()).hexdigest()==meta['csv_extract_sha256']
    checks['csv_sha256_matches_pinned_extract']=True
    df=pd.read_csv(ROOT/'data/ais_records.csv',parse_dates=['ts'])
    assert len(df)==84702 and df.MMSI.nunique()==100 and df.fid.is_unique
    assert int((df.ts.dt.hour<8).sum())==22550
    checks['source_rows_and_split']=True
    runs=pd.read_csv(ROOT/'results/test_runs.csv')
    assert len(runs)==800 and runs.seed.nunique()==20 and runs.policy.nunique()==8
    assert (runs.records==62152).all()
    assert (runs.lost_output_records==0).all() and (runs.duplicate_effect_records==0).all()
    ad=runs[runs.policy=='adaptive']
    assert len(ad)==100
    assert ((ad.publish_wait_p99<=60)&(ad.risk_exceed_fraction<=.01)).all()
    checks['all_100_adaptive_primary_runs_meet_budgets']=True
    checks['simulated_atomic_prefix_invariants']=True
    assert np.allclose(runs.successful_incremental_mib,runs.records*128/2**20)
    assert np.allclose(runs.successful_metadata_mib,runs.successful_checkpoints*16384/2**20)
    assert np.allclose(runs.checkpoint_mib,runs.successful_incremental_mib+runs.successful_metadata_mib+runs.failed_written_mib)
    assert (runs.publish_deadline_miss_count==np.rint(runs.records*runs.publish_deadline_miss_fraction)).all()
    assert (runs.miss_with_rollback_count+runs.miss_without_rollback_count==runs.publish_deadline_miss_count).all()
    assert (runs.exposure_exceed_ticks<=runs.exposure_ticks).all()
    assert (runs.active_failures_over_budget<=runs.active_failures).all()
    assert (runs.blocked_any_events<=runs.blocked_any_ticks).all()
    checks['write_decomposition_tail_exposure_blocking_consistent']=True
    # Compare the binary search against independent complete enumeration.
    rng=np.random.default_rng(20261109);cfg=Config()
    for _ in range(1000):
        u=int(rng.integers(0,900));age=float(rng.integers(0,100));rate=float(rng.uniform(0,48))
        bw=float(rng.uniform(8192,131072));elapsed=int(rng.integers(0,130))
        for policy in ('adaptive','no_age','no_forecast'):
            feasible=[]
            for h in range(max(0,int(cfg.max_interval-elapsed))+1) if elapsed<=cfg.max_interval else []:
                dur=future_duration(u,rate,h,bw,cfg)
                age_ok=(policy=='no_age' or age+h+dur+1<=cfg.visible_budget)
                work_ok=u+rate*(h+(0 if policy=='no_forecast' else dur+1))<=cfg.replay_budget
                if age_ok and work_ok:feasible.append(h)
            assert latest_wait(u,age,rate,bw,elapsed,cfg,policy)==max(feasible,default=-1)
    checks['integer_search_matches_3000_enumerated_local_problems']=True
    tx=pd.read_csv(ROOT/'results/transaction_fault_tests.csv')
    good=tx[tx.atomic]
    assert len(good)==24 and (good.missing_effects==0).all() and (good.duplicate_effects==0).all()
    assert good.window_counts_equal.all() and good.distinct_pairs_equal.all()
    assert tx[~tx.atomic].missing_effects.sum()>0 and tx[~tx.atomic].duplicate_effects.sum()>0
    checks['actual_sqlite_atomic_trials_and_negative_controls']=True
    sens=pd.read_csv(ROOT/'results/sensitivity_runs.csv')
    tune=pd.read_csv(ROOT/'results/sensitivity_training_runs.csv')
    assert len(sens)==180 and len(tune)==1080
    assert set(tune.seed)<=set(range(4)) and set(sens.seed)<=set(range(100,106))
    checks['sensitivity_fixed_baselines_use_training_only']=True
    nb=json.loads((ROOT/'检查点调度_AIS复现实验V2.ipynb').read_text())
    for cell in nb['cells']:
        if cell['cell_type']=='code':
            assert cell['execution_count'] is not None
            assert not any(o['output_type']=='error' for o in cell['outputs'])
    checks['notebook_executed_without_errors']=True
    doc=ROOT/'report/检查点调度模型与公开AIS验证V2.docx'
    with zipfile.ZipFile(doc) as z:
        xml=z.read('word/document.xml').decode()
        assert xml.count('<m:oMathPara')>=8
        assert '\\tag{' not in xml and '\\widehat' not in xml
        from lxml import etree
        root=etree.fromstring(z.read('word/document.xml'))
        ns={'m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
        math_text=''.join(root.xpath('.//m:t/text()',namespaces=ns))
        assert not any(bad in math_text for bad in ['qquad','frac','widehat','mathrm','operatorname','mathcal'])
        assert len(root.findall('.//m:f',ns))>=9
        md=(ROOT/'report/revised_research_sections.md').read_text()
        assert not any(ord(c)<32 and c not in '\n\t' for c in md)
    checks['docx_native_equations_no_latex_fallback']=True
    for i in range(1,8):assert any((ROOT/'figures').glob(f'{i:02d}_*.png'))
    checks['seven_standalone_figures']=True
    (ROOT/'results/verification.json').write_text(json.dumps(checks,indent=2))
    print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
