# 检查点调度与公开 AIS 验证

这是固定计算图上的检查点时间调度研究原型。公开 AIS 记录驱动模拟负载；SQLite 另行核验单数据库原子事务。没有将模拟结果当作实测 Flink 集群性能。

## 打开与运行

1. 解压整个项目，保留 src、data、results、figures、provenance 目录。
2. 建议 Python 3.10 或以上，安装 `pip install -r requirements.txt`。
3. 在解压目录打开 `检查点调度_AIS复现实验.ipynb`。Notebook已执行并保留真实输出。
4. 完整重跑依次执行：

```bash
python src/study.py
python src/transaction_check.py
python src/make_figures.py
python src/verify_results.py
```

完整回放包含校准、留出实验和敏感性分析。`--quick --skip-sensitivity` 只用于快速检查，会改写结果；需要恢复正式结果时请完整重跑。

## 公开数据

上游：MovingPandas示例，数据说明归属于Danish Maritime Authority，2017年7月5日哥德堡附近。
来源说明：https://github.com/movingpandas/movingpandas-examples/blob/main/data/README.md
固定原文件：https://raw.githubusercontent.com/movingpandas/movingpandas-examples/5e67be5df737ca7a5af321e8524e7691dd8dddf9/data/ais.gpkg

`data/ais_records.csv` 是原文件的非几何字段提取，含84,702条记录、100个MMSI。原始GeoPackage不重复打包；需要时执行 `python src/download_data.py` 下载固定版本并核对SHA256。下载元数据和提取CSV的SHA256在 `provenance/download.json`。未使用的船名、坐标几何不包含在本项目提取表中。

## 模型和单位

每回放秒观测未保护处理量、最早待提交更新的年龄和预计快照耗时。选择预算允许的最晚触发时间；不修改原子提交协议，不提前公开未成功检查点的结果。

原始观测时间以12倍速度重放。2小时和6小时断链是基于原始事件时域的人为注入；检查点与性能指标以回放秒计。到达时间、硬件能力、保存字节模型和任务故障均为明确实验条件，不是公开AIS数据中观测到的运行指标。

控制器历史在工作进程故障期间保留。单条记录工作量取1；数据来自同一天一个区域，不能据此外推生产部署的绝对时延。

## 文件

- `src/study.py`：模型、在线触发规则、模拟器、校准、主实验和敏感性。
- `src/transaction_check.py`：实际SQLite事务故障注入及非原子反例。
- `src/make_figures.py`：PNG和SVG研究图。
- `src/build_notebook.py`：重建并执行Notebook，无需nbformat包。
- `src/build_report.py`：报告内容和原生Word公式，生成需Pandoc。
- `results/test_runs.csv`：700次主实验逐次结果。
- `results/paired_comparison.csv`：配对差和95%自助法区间。
- `results/sensitivity_runs.csv`：132次敏感性运行。
- `results/sensitivity_training_runs.csv`：各敏感性条件固定基线的校准明细。
- `results/transaction_fault_tests.csv`：24次正向事务试验和12次非原子反例。

核心结论：在给定预算和实验条件下，自适应方案减少检查点写入；相对频繁固定保存，其等待和故障重算量更大。请结合报告中的权衡解读结果，不将某项下降幅度等同于总成本下降。
