from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from study import ROOT,Config,make_trace

BLUE='#146B8C'; ORANGE='#C87C3C'; GRAY='#64748B'; LIGHT='#E5EDF2'
SCENARIOS=['normal','outage2h','outage6h','io_slow','combined']
SLABEL=['Normal','2 h outage','6 h outage','Slow storage','Combined']
PLABEL={'fixed':'Fixed 15 s','backlog':'Backlog timer','rate':'Rate only',
        'count':'Count only','adaptive':'Budgeted online','no_age':'Without age guard',
        'no_forecast':'Without reserve'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
 'axes.spines.right':False,'axes.labelcolor':'#26394A','axes.edgecolor':'#94A3B8',
 'axes.titleweight':'bold','axes.titlesize':11,'figure.facecolor':'white',
 'savefig.facecolor':'white','grid.color':LIGHT,'grid.linewidth':.7,
 'svg.fonttype':'none'})

def finish(fig,name):
    fig.tight_layout(pad=1.5)
    fig.savefig(ROOT/f'figures/{name}.png',dpi=220,bbox_inches='tight')
    fig.savefig(ROOT/f'figures/{name}.svg',bbox_inches='tight')
    plt.close(fig)

def main():
    df=pd.read_csv(ROOT/'data/ais_records.csv',parse_dates=['ts'])
    runs=pd.read_csv(ROOT/'results/test_runs.csv')
    summary=runs.groupby(['scenario','policy']).mean(numeric_only=True)
    minute=df.groupby(df.ts.dt.floor('min')).size()
    fig,axs=plt.subplots(2,1,figsize=(9.2,6.3))
    h=(minute.index-minute.index[0]).total_seconds()/3600
    axs[0].plot(h,minute.values,lw=.85,color=BLUE)
    axs[0].axvspan(0,8,color=LIGHT,alpha=.75,label='Calibration 00:00-08:00')
    axs[0].axvline(8,color=GRAY,ls='--',lw=1)
    axs[0].set(xlabel='Hour in original AIS timestamps',ylabel='AIS rows / minute',
               title='Public observations: 84,702 AIS rows, 100 vessels')
    axs[0].legend(frameon=False,loc='upper left');axs[0].grid(axis='y')
    for sc,col in [('normal',BLUE),('outage6h',ORANGE)]:
        tr=make_trace(df,'test',sc,Config())
        b=np.bincount((tr['arrival']//20).astype(int))/20
        axs[1].plot(np.arange(len(b))*20/60,b,color=col,lw=1.2,label=sc)
    axs[1].set(xlabel='Replay minute (12x event-time compression)',ylabel='Arriving rows / replay s',
               title='Controlled input perturbation: six-hour event-time outage and catch-up')
    axs[1].legend(frameon=False);axs[1].grid(axis='y')
    finish(fig,'01_public_trace')

    fig,axs=plt.subplots(2,2,figsize=(10,7.2))
    metrics=[('checkpoint_mib','Checkpoint writes (MiB)'),
             ('publish_wait_p99','Mean of run-level P99 waits (replay s)'),
             ('replay_per_failure','Recomputed rows per failure'),
             ('risk_exceed_fraction','Time above replay budget (%)')]
    for ax,(met,label) in zip(axs.flat,metrics):
        for j,(pol,col) in enumerate([('fixed',ORANGE),('adaptive',BLUE)]):
            vals=np.array([summary.loc[(sc,pol),met] for sc in SCENARIOS])
            if met=='risk_exceed_fraction':vals*=100
            ax.bar(np.arange(5)+(j-.5)*.34,vals,width=.33,color=col,label=PLABEL[pol])
        ax.set_xticks(range(5),SLABEL,rotation=18,ha='right');ax.set_ylabel(label)
        ax.grid(axis='y');ax.set_axisbelow(True)
        if met=='publish_wait_p99':ax.axhline(60,color=GRAY,ls='--',lw=1,label='60 s budget')
        if met=='risk_exceed_fraction':ax.axhline(1,color=GRAY,ls='--',lw=1,label='1% target')
    axs[0,0].legend(frameon=False)
    fig.suptitle('Held-out AIS replay: 20 paired failure seeds per scenario',fontsize=13,y=1.01)
    finish(fig,'02_tradeoffs')

    fig,axs=plt.subplots(1,2,figsize=(10,4.3))
    diag=pd.read_csv(ROOT/'results/fixed_test_diagnostic.csv')
    markers={'adaptive':'*','fixed':'s','backlog':'v','rate':'^','count':'o'}
    for ax,sc in zip(axs,['normal','combined']):
        dd=diag[diag.scenario==sc].groupby('fixed').mean(numeric_only=True)
        ax.plot(dd.publish_wait_p99,dd.checkpoint_mib,color=LIGHT,lw=1.4,zorder=1)
        for interval,row in dd.iterrows():
            ok=row.publish_wait_p99<=60 and row.risk_exceed_fraction<=.01
            ax.scatter(row.publish_wait_p99,row.checkpoint_mib,color=GRAY if ok else '#CBD5E1',s=25,zorder=2)
            ax.annotate(f'{int(interval)}', (row.publish_wait_p99,row.checkpoint_mib),xytext=(3,4),textcoords='offset points',fontsize=7,color=GRAY)
        for pol,col in [('adaptive',BLUE),('fixed',ORANGE),('backlog','#7B6E99'),('rate','#568B76'),('count','#A3766B')]:
            row=summary.loc[(sc,pol)]
            ax.scatter(row.publish_wait_p99,row.checkpoint_mib,color=col,s=120 if pol=='adaptive' else 55,
                       marker=markers[pol],label=PLABEL[pol],zorder=4)
        ax.axvline(60,color=GRAY,ls='--',lw=1)
        ax.set(xlabel='Mean run-level P99 publish wait (replay s)',ylabel='Checkpoint writes (MiB)',
               title='Normal input' if sc=='normal' else 'Outage plus slow storage')
        ax.grid(axis='y')
    axs[1].legend(frameon=False,fontsize=8,loc='upper right')
    fig.suptitle('Resource / freshness frontier; gray labels are fixed intervals in seconds',fontsize=12,y=1.02)
    finish(fig,'03_frontier')

    fig,axs=plt.subplots(3,1,figsize=(10,7.5),sharex=True)
    for pol,col in [('fixed',ORANGE),('adaptive',BLUE)]:
        tl=pd.read_csv(ROOT/f'results/timeline_{pol}.csv')
        cp=pd.read_csv(ROOT/f'results/checkpoints_{pol}.csv')
        xx=tl.t/60
        axs[0].plot(xx,tl.queue,color=col,lw=1,label=PLABEL[pol])
        axs[1].plot(xx,tl.unprotected,color=col,lw=.9)
        intervals=np.diff(cp.start)
        axs[2].plot(cp.start.to_numpy()[1:]/60,intervals,color=col,lw=.8,marker='.',ms=2)
    axs[1].axhline(600,color=GRAY,ls='--',lw=1)
    axs[0].set(ylabel='Unprocessed rows',title='Combined held-out scenario, shared failure seed 100')
    axs[1].set(ylabel='Processed but uncommitted rows')
    axs[2].set(ylabel='Start-to-start interval (s)',xlabel='Replay minute')
    axs[0].legend(frameon=False)
    for ax in axs:ax.grid(axis='y')
    finish(fig,'04_online_timeline')

    sens=pd.read_csv(ROOT/'results/sensitivity_runs.csv')
    rows=[]
    for (param,val),g in sens.groupby(['sensitivity_parameter','sensitivity_value'],sort=False):
        z=g.groupby('policy').mean(numeric_only=True)
        rows.append((f'{param} = {val:g}',100*(1-z.loc['adaptive','checkpoint_mib']/z.loc['fixed','checkpoint_mib']),
                     z.loc['adaptive','publish_wait_p99'],z.loc['adaptive','risk_exceed_fraction']*100))
    fig,axs=plt.subplots(1,2,figsize=(10,5.7),sharey=True)
    yy=np.arange(len(rows))
    axs[0].barh(yy,[x[1] for x in rows],color=BLUE,height=.65)
    axs[0].set_yticks(yy,[x[0] for x in rows],fontsize=8)
    axs[0].set_xlabel('Checkpoint write reduction vs. retrained fixed (%)')
    axs[1].barh(yy,[x[3] for x in rows],color='#5D9F9A',height=.65)
    axs[1].set_xlabel('Adaptive time above replay budget (%)')
    axs[1].axvline(1,color=GRAY,ls='--',lw=1)
    axs[0].invert_yaxis()
    for ax in axs:ax.grid(axis='x');ax.set_axisbelow(True)
    fig.suptitle('Sensitivity: 6 paired test seeds; fixed comparator recalibrated on training data',fontsize=11,y=1.01)
    finish(fig,'05_sensitivity')
    print('Created 5 figures as PNG and SVG')

if __name__=='__main__':main()
