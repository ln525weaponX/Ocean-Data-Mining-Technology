"""Build the Chinese research report with native Word equations via Pandoc."""
from __future__ import annotations
import json,subprocess,re
from pathlib import Path
import numpy as np,pandas as pd
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from study import ROOT

def table(headers,rows):
    return '\n'.join(['|'+'|'.join(map(str,headers))+'|','|'+'|'.join(['---']*len(headers))+'|']+
                     ['|'+'|'.join(map(str,r))+'|' for r in rows])+'\n'

def main():
    result=ROOT/'results';rep=ROOT/'report';rep.mkdir(exist_ok=True)
    ds=json.loads((result/'dataset_statistics.json').read_text())
    plan=json.loads((result/'experiment_plan.json').read_text())
    tx=json.loads((result/'transaction_check_summary.json').read_text())
    provenance=json.loads((ROOT/'provenance/download.json').read_text())
    runs=pd.read_csv(result/'test_runs.csv')
    g=runs.groupby(['scenario','policy']).mean(numeric_only=True)
    dif=pd.read_csv(result/'paired_comparison.csv').set_index(['scenario','metric'])
    sens=pd.read_csv(result/'sensitivity_runs.csv')
    names={'normal':'正常输入','outage2h':'两小时断链补传','outage6h':'六小时断链补传','io_slow':'存储带宽降低','combined':'断链与存储降速叠加'}
    c=[]
    c.append('''---
title: 检查点调度模型与公开AIS数据验证
subtitle: 固定计算图下的在线时间调度与原子提交
date: 2026年11月8日
lang: zh-CN
---

# 研究结论与证据范围

本报告提出一个初步的预算约束在线检查点调度模型。在固定计算图和一致性协议下，调度器根据尚未被成功检查点覆盖的处理量、待提交更新的年龄以及预计保存耗时，决定下一次全局检查点何时触发。其目标是在满足发布等待和恢复风险预算的条件下减少检查点写入。

验证分为两部分。第一部分使用公开AIS记录驱动离散时间模拟，检验不同调度策略的资源与时效权衡；第二部分执行SQLite原子事务故障回放，实际核对输入进度、窗口计数与审计记录。前者提供调度性能证据，后者提供单数据库事务边界内的正确性证据。
''')
    normal=dif.loc[('normal','checkpoint_mib')];combined=dif.loc[('combined','checkpoint_mib')]
    c.append(f'''公开样本共{ds['records']:,}条记录、{ds['ships']}艘船。主实验包含5种场景、7种策略、20个共同故障种子，共700次留出时段回放。与只在校准时段选出的15秒固定间隔相比，自适应方案在正常场景减少检查点写入{normal.relative_reduction_pct:.2f}%，在叠加压力场景减少{combined.relative_reduction_pct:.2f}%。100次自适应主实验均满足“单次运行发布等待P99不超过60回放秒、风险超预算时间占比不超过1%”的验收条件。

这项收益伴随更长的等待和更大的故障重算量。例如正常场景的发布等待P99均值由20.12升至56.25回放秒，平均每次故障重算记录数由123.09升至282.13。该方案体现的是预算内资源节省，不是所有性能指标同时改善。

事务回放包含{tx['atomic_trials']}个正向试验，每次处理{tx['records_per_trial']:,}条公开输入记录，注入{tx['injected_crashes']}次异常，其中{tx['commit_ack_losses']}次发生在提交成功但确认丢失之后。审计中未发现缺失或重复生效。此结果不等同于已经完成分布式Flink集群验证。
''')
    c.append(r'''
# 研究定位与已有基础

检查点放置与检查点时间调度是不同问题。前者选择在哪些算子、节点或路径保存状态，后者在既定计算图上决定何时保存。本模型研究后者，仅调节全局检查点触发时间，不改变算子位置、窗口定义、水位线策略或事务提交协议。

已有研究并非都采用静态规划。Ca-Stream于2025年提出结合故障率、CPU、内存和慢任务进行检查点自适应调整[2]。Flink 1.19已提供积压期间使用更长检查点间隔的机制[3]。因此，本模型的候选改进点是把实际重算预算与结果可见时限共同转化为在线触发条件，并在海洋断链补传负载上验证；不将“动态调整间隔”本身宣称为首次提出。

课程第五讲要求区分事件时间与处理时间、状态与输入进度、内部一致性与外部交付效果。本报告保留这些边界。地面站断链用于构造输入扰动，计算工作进程故障用于检验恢复，两者分别模拟。

# 初步调度模型

## 系统边界与符号

一条可重放输入日志连接一个有状态处理任务和一个原子提交结果域。检查点捕获已经完成处理的日志前缀；完成持久化后，该前缀的结果正式可见。任务故障时恢复到最近成功检查点的前缀。只允许一个在途检查点，保存期间处理能力可受I/O竞争影响，但处理不必完全停止。
''')
    c.append(table(['符号','含义','单位'],[
      ['$A_t$','截至时刻t已经进入日志的累计记录数','条'],
      ['$p_t$','累计处理进度 完整记录数为其下取整','条'],
      ['$c_t$','最近已持久化且已提交的输入前缀','条'],
      ['$u_t$','已处理但尚未受成功检查点保护的记录数','条'],
      ['$a_t$','最早待提交更新自首次处理完成后的年龄','回放秒'],
      ['$S_t$','本次预计保存字节数','字节'],
      [r'$\widehat B_t$','依据已完成检查点估计的有效写带宽','字节每回放秒'],
      ['$D$ 与 $R$','发布等待预算与重算记录预算','回放秒 与 条'],
      ['$x_t$','时刻t是否请求启动检查点','0或1']]))
    c.append(r'''
输入积压和未保护工作量分别为

$$q_t=A_t-p_t,\qquad u_t=\lfloor p_t\rfloor-c_t. \tag{1}$$

本例将每条记录的计算工作量设为1，因此用记录数表示重算量；今后可用各类记录的实测处理成本替换为加权工作量。MMSI不作为交付去重键，交付单位是公开文件中的行标识fid。相同属性但不同fid仍是不同输入记录。业务船数另按事件时间窗口与MMSI做distinct统计。

## 状态与检查点成本

设每船状态代理规模为$b_s$，每次记录更新产生的增量代理为$b_u$，每次快照含固定元数据$s_0$，则

$$S_t=s_0+\min\{b_s n_t,\ b_u u_t\}. \tag{2}$$

其中$n_t$是已处理前缀涉及的不同船舶数。此字节模型是明确设置的实验模型，不是由AIS文件大小反推的Flink状态测量值。实际模拟按每秒带宽排空待写字节，支持保存过程中带宽改变。在线估计使用

$$\widehat d_t=\left\lceil d_0+S_t/\widehat B_t\right\rceil. \tag{3}$$

保存期间处理能力设为正常能力的$1-\eta$倍，故障恢复期间处理暂停。完成一个检查点后，只发布其启动时已捕获的前缀；保存期间继续处理的记录由后续检查点保护。

## 目标与验收条件

完整时域目标是在可见性与恢复风险预算下减少实际检查点写入字节，包含失败检查点已经写出的部分：

$$\min_{\{x_t\}}\ J=\sum_k S_k^{\rm written}. \tag{4}$$

设$L_i$为记录i首次处理完成到其贡献正式提交的等待时间。验收目标为

$$Q_{0.99}(L_i)\le D,\qquad
\frac{\sum_{t\in\mathcal A}{\bf1}(u_t>R)}{|\mathcal A|}\le\varepsilon_R. \tag{5}$$

$\mathcal A$是非恢复暂停的模拟时间步。本例取$D=60$回放秒、$R=600$条、$\varepsilon_R=0.01$。这两项是性能预算，不允许用丢弃输入或提前提交未完成检查点来满足。运行中同时检查一致性不变量$c_t\le\lfloor p_t\rfloor\le A_t$以及已提交前缀单调递增。

这些约束是设计和验收目标。在线控制依赖预测，遇到突变时可能短暂超预算；实验直接报告超预算时间比例，不把预测值当作硬保证。

## 在线局部决策及解析形式

每回放秒观测当前状态。用指数滑动平均估计处理速率，并以标准差留出余量：

$$\widehat r_t^+=\min\{\mu,\ \overline r_t+0.75\sigma_t\}. \tag{6}$$

输入队列超过正常处理能力3秒的量时，速率保护值至少取保存期间的可处理能力。速率更新系数为0.08；带宽估计仅在检查点成功后以0.3的系数更新。算法不读取未来到达率、未来故障或未来存储扰动。

冻结当前预测系数，令h为继续等待触发的时长，采用如下局部近似：

$$\max_{h\ge0}\ h,\quad
a_t+h+\widehat d_t+\delta\le D,\quad
u_t+\widehat r_t^+(h+\widehat d_t+\delta)\le R. \tag{7}$$

再限制最大间隔后，最晚可等待时间为

$$h_t^*=\min\left\{
D-a_t-\widehat d_t-\delta,\quad
\frac{R-u_t}{\widehat r_t^+}-\widehat d_t-\delta,\quad
T_{\max}-(t-s_{\rm last})\right\}. \tag{8}$$

当速率估计为0时，第二项按当前是否超出预算分别视为无穷或立即到期。离散实现取安全余量$\delta=1$回放秒。当$h_t^*\le0$且协调器允许启动时触发，否则等待一个时间步后重估。无待提交更新时不保存空快照。检查点在途、最小间隔和最小暂停约束始终优先遵守；最后一批输入处理结束后补做最终提交。

固定元数据使频繁快照产生额外写入；在增量更新量近似给定时，尽量晚但不越过预算地触发，是一个成本导向的局部贪心策略。式8是冻结预测下局部子问题的解析解，不构成随机完整时域问题的全局最优性证明。

# 公开数据与可复现实验设计

## 数据来源与划分

数据采用MovingPandas公开示例ais.gpkg。项目说明将其归属于丹麦海事管理局，覆盖2017年7月5日哥德堡附近船舶活动[1]。本次从固定Git提交下载原始GeoPackage，提取fid、Timestamp、MMSI、SOG、COG、NavStatus与ShipType。只使用相对时间，不额外推定原字段未标明的时区。
''')
    c.append(table(['项目','实际值'],[
       ['原始记录数',f"{ds['records']:,}"],['不同MMSI数',ds['ships']],
       ['时间范围',ds['start']+' 至 '+ds['end']],
       ['校准时段与记录数',f"00:00至08:00 共{ds['train_records']:,}条"],
       ['留出时段与记录数',f"08:00至24:00 共{ds['test_records']:,}条"],
       ['每分钟记录数 中位数与最大值','56 与 153'],
       ['SOG缺失 COG缺失',f"{ds['sog_missing']} 与 {ds['cog_missing']}"],
       ['时间 MMSI SOG COG字段重复的后续行数',ds['repeated_attribute_rows']]]))
    c.append(f'''
537条属性重复的后续行予以保留，因为它们是公开日志中的不同输入行；不能把源记录重复与恢复过程重复生效混为一谈。SOG与COG缺失不影响本次基于时间和行标识的负载调度。

固定提交为 `{provenance['url'].split('/')[5]}`。原始文件SHA256为

`{provenance['sha256']}`

完整来源、下载时间、字节数与CSV提取哈希保存在项目的provenance目录。

![图1 公开AIS负载与受控补传场景](../figures/01_public_trace.png){{width=6.3in}}

## 事实负载与实验假设

原始数据只给出观测时间，不提供本次所需的端到端到达时间、检查点成本或任务故障记录。实验将原始观测间隔以12倍速回放，并在此基线上注入明确的扰动。原始事件时间及MMSI保持不变。所有性能时间均为回放时钟单位，不能直接解释为生产部署的秒数。
''')
    c.append(table(['参数','默认设置','性质'],[
       ['正常处理能力','48条每回放秒','人为设置'],
       ['检查点固定准备耗时','1.5回放秒','人为设置'],
       ['固定元数据 每条更新代理','16 KiB 与128字节','人为设置'],
       ['每船状态代理','4 KiB','人为设置'],
       ['正常检查点存储带宽','64 KiB每回放秒','人为设置'],
       ['保存期间处理能力损失','35%','人为设置'],
       ['恢复暂停与恢复读取带宽','8回放秒 与256 KiB每回放秒','人为设置'],
       ['故障间隔均值','900回放秒 指数分布','压力测试假设'],
       ['最小启动间隔 最小完成后暂停','3回放秒 与1回放秒','协调约束'],
       ['发布等待预算 重算预算','60回放秒 与600条','设计目标']]))
    c.append('''
计算工作进程故障时处理进度回滚至最近成功提交前缀，正在进行的检查点作废。调度控制器及监控历史在这些工作进程故障中保留，本次没有模拟协调器自身崩溃。为便于核对，单条记录处理成本取1，状态大小及存储带宽也通过敏感性分析改变。

五种留出场景包括正常输入、两小时事件时间断链补传、六小时事件时间断链补传、存储降速和两小时断链叠加存储降速。断链从该分段时域的28%处开始，恢复后以事件进度6倍速度释放被扣留记录，同时正常实时输入继续进入。存储降速时段为时域的18%至36%、65%至79%，带宽降为正常值的四分之一。按相同到达时间与fid稳定排序构成可重放日志。

## 基线与公平比较

固定间隔候选为5、10、15、20、30、45、60、90、120回放秒。只在前8小时的正常和叠加场景、故障种子0至7上选择固定基线。先筛选发布等待P99均值不超过60且风险超预算平均时间比例不超过1%的候选，再选择平均写入量最小者。本次选出15秒。若没有可行候选，代码采用显式约束惩罚，避免静默使用测试结果。

主实验使用后16小时和故障种子100至119；相同场景与种子下，各策略共用到达序列、故障时刻和存储扰动。七种策略分别为固定间隔、积压时延长间隔的简化基线、仅依据速率决定间隔、仅按记录数量触发、本模型、去掉年龄保护、去掉在途保存余量。积压基线只模拟两档间隔思想，不宣称是Flink连接器完整实现；不将本次结果当作与Ca-Stream的直接跑分比较。

另扫描留出数据上的固定间隔前沿，作为事后诊断，不参与参数选择。敏感性试验为每种新参数重新在校准数据上选择固定基线，而自适应控制系数保持不变。

# 留出回放结果

## 资源与时效的权衡

下表每个数值为20次共同故障种子的均值；P99列是先对每次运行计算P99，再对20次运行求均值，不是把所有运行合并后的总体P99。单元格中的箭头均表示固定15秒方案到自适应方案。
''')
    rows=[]
    for sc,label in names.items():
        f=g.loc[(sc,'fixed')];a=g.loc[(sc,'adaptive')]
        rows.append([label,f'{f.checkpoint_mib:.2f} → {a.checkpoint_mib:.2f}',
           f'{f.publish_wait_p99:.2f} → {a.publish_wait_p99:.2f}',
           f'{100*f.risk_exceed_fraction:.2f} → {100*a.risk_exceed_fraction:.2f}',
           f'{f.replay_per_failure:.1f} → {a.replay_per_failure:.1f}'])
    c.append(table(['场景','写入 MiB','发布等待P99 回放秒','风险超预算时间 %','每次故障重算 条'],rows))
    c.append('''
正常场景检查点写入下降23.86%，叠加压力场景下降18.76%；其他三个场景的下降范围为8.80%至23.22%。所有100次自适应主试验同时满足设定的两项验收条件；固定基线在正常和仅存储降速场景也全部满足，但在两种断链与叠加压力场景中均超过1%的风险时间比例目标。

自适应方案的发布等待更接近预算上界，故障重算量也更大。因此，对需要20秒内可见或更小重算量的业务，应收紧相应预算后重新调度。检查点写入下降不等同于总存储成本或总CPU成本下降相同比例。

![图2 留出实验的资源 时效与恢复代价](../figures/02_tradeoffs.png){width=6.3in}
''')
    cirows=[]
    for sc in ('normal','combined'):
        z=dif.loc[(sc,'checkpoint_mib')]
        cirows.append([names[sc],f'{z.paired_difference:.4f}',f'[{z.ci_low:.4f}, {z.ci_high:.4f}]',f'{z.relative_reduction_pct:.2f}%'])
    c.append(table(['场景','写入配对差 MiB','差值95%自助法区间','相对降幅'],cirows))
    c.append('''
自助法以共同故障种子的配对差进行3000次重采样，区间衡量本次故障随机性下的波动，不代表对其他海域或硬件条件的总体置信区间。

![图3 固定间隔前沿与在线策略位置](../figures/03_frontier.png){width=6.3in}

图3的固定间隔前沿使用4个测试种子作为诊断，标注数字为固定间隔。正常场景固定30秒的写入量接近自适应，但风险超预算时间约3.6%；仅比较写入量会遗漏恢复预算的差别。前沿诊断不参与控制器训练，也不替代主实验20种子的配对结果。

## 可见性与输入排队需要分别解释

记录级发布等待从首次处理完成开始计时；日志到可见延迟还包含排队与恢复。叠加压力场景中，两种策略日志到可见P99均值约为139.58与137.99回放秒，差值的95%配对区间跨过0，不能据此主张稳定的端到端时延优势。六小时补传场景中，该指标反而由372.19升至377.05回放秒。资源预算调度不能消除源端断链和超过处理能力的输入积压。

![图4 同一故障种子下的在线调度过程](../figures/04_online_timeline.png){width=5.7in}

## 消融与敏感性

叠加压力场景的消融结果如下。年龄保护控制低负载时的发布等待；在途保存余量控制快照完成前仍会继续增长的未保护工作。
''')
    abrows=[]
    for pol,label in [('adaptive','完整模型'),('no_age','去掉年龄保护'),('no_forecast','去掉保存余量'),('rate','仅按速率'),('count','仅按数量')]:
        z=g.loc[('combined',pol)]
        abrows.append([label,f'{z.checkpoint_mib:.3f}',f'{z.publish_wait_p99:.2f}',f'{100*z.risk_exceed_fraction:.2f}%'])
    c.append(table(['方案','写入 MiB','发布等待P99 回放秒','风险超预算时间'],abrows))
    c.append('''
去掉年龄保护后，平均P99升至约95.90，超过60的目标；去掉保存余量后，风险超预算时间升至约7.5%。这表明两个约束分别起作用，资源减少并非单纯依赖放宽所有保护。

敏感性覆盖无故障、较低与较高故障频率、二分之一与两倍存储带宽、保存期间0与70%的能力损失、40与90的发布预算、400与900的重算预算。每种参数使用6个测试种子，共132次运行；固定对照在校准数据上重新选择。结果见图5及原始CSV。更紧的重算预算或发布预算会增加自适应检查点写入，符合模型机制。

![图5 对重新校准固定基线的敏感性比较](../figures/05_sensitivity.png){width=6.3in}

# 原子提交故障回放

性能模拟中的原子前缀提交是一项协议假设，不能用同一假设自行证明正确性。为此，另执行实际SQLite事务试验[6]：使用叠加场景按到达顺序排列的前8000条公开记录，并采用固定与自适应回放产生的提交边界。

每批事务同时更新输入游标、按原始事件时间10分钟窗口累加的报文计数、窗口船舶集合和审计日志。报文计数使用加法更新，重复执行会产生额外效果。审计日志对fid没有唯一约束，因此审计不会通过去重掩盖重复提交。恢复后首先读取持久游标，再决定下一批。

异常分别注入事务开始前、结果更新后游标更新前、游标更新后提交前，以及提交成功但确认丢失后。故障通过关闭数据库连接模拟工作进程中断；没有实施操作系统断电或存储损坏实验。
''')
    c.append(table(['核验项目','实际结果'],[
      ['正向原子事务试验',f"{tx['atomic_trials']}次 每次{tx['records_per_trial']:,}条"],
      ['注入异常总数',tx['injected_crashes']],['提交成功后确认丢失',tx['commit_ack_losses']],
      ['缺失效果 重复效果',f"{tx['missing_effects']} 与 {tx['duplicate_effects']}"],
      ['窗口报文数与批量真值','全部一致'],['窗口不同船舶集合与批量真值','全部一致'],
      ['先提交结果后保存游标的反例','累计5931次重复效果'],
      ['先保存游标后提交结果的反例','累计5931条缺失效果']]))
    c.append('''
两个反例各覆盖6次试验；反例总数是跨试验累计值。正向试验共处理192000条记录贡献。该实验支持“改变调度边界无需改变单库原子提交正确性”的可行性判断，尚不涉及跨数据库事务、Flink全局屏障恢复、协调器失效或外部短信发送。

# 可行性判断与下一阶段

本次初步验证支持三个结论。第一，公开AIS负载可以驱动检查点时间调度实验，源断链与任务故障可以分开控制。第二，基于预算的在线触发在本次留出与压力设置下，能够以更长但受控的发布等待换取更少快照写入，并降低突发期间超过重算预算的时间比例。第三，单数据库原子事务能使不同提交边界在本次故障回放中得到相同批量真值。

证据范围也需要保留。只有一天、一个区域的100艘船样本，不能表征所有海域；到达时间、硬件能力、状态字节数和故障分布是实验假设；故障只影响工作进程而保留控制器历史；本报告尚未对比Ca-Stream完整实现；当前解析规则是局部预测贪心而非全局最优算法。

下一阶段建议保持本模型及数据回放不变，在Flink和事务下游中实测检查点增量字节、完成耗时、提交可见时间和恢复工作量，用实测函数替换式2与式3。先验证间隔调度，再将对齐等待和在途缓冲字节加入检查点方式选择。扩展数据时优先增加多日、多站点及真实接收时间，随后检验跨日和跨站点泛化。

# 复现与文件说明

项目压缩包包含公开AIS字段提取CSV、数据来源与哈希、模拟代码、实际事务核验代码、所有运行明细、图像和可执行Notebook。Notebook放在解压目录根部，与data和src目录同级。安装requirements.txt后，可依次执行以下命令。

```text
python src/study.py
python src/transaction_check.py
python src/make_figures.py
```

完整复现使用已附CSV，不要求重新下载原始GeoPackage。需要重建提取过程时执行python src/download_data.py，程序会核对固定版本原始文件SHA256。所有随机种子、参数、固定基线选择结果与原始指标均随项目提供。

# 参考资料

[1] MovingPandas Examples. Example datasets README 与固定版本ais.gpkg。数据说明指向Danish Maritime Authority。https://github.com/movingpandas/movingpandas-examples/blob/main/data/README.md

[2] Sun D, Peng J, Zhu T, Kua J, Gao S, Buyya R. Toward High Availability Distributed Stream Computing Systems via Checkpoint Adaptation. Concurrency and Computation Practice and Experience, 2025, 37, e70171. https://doi.org/10.1002/cpe.70171

[3] Apache Flink. Announcing the Release of Apache Flink 1.19. 2024年3月18日。https://flink.apache.org/2024/03/18/announcing-the-release-of-apache-flink-1.19/

[4] Apache Flink. Fault Tolerance 与 Checkpointing under Backpressure 文档。https://nightlies.apache.org/flink/flink-docs-stable/docs/learn-flink/fault_tolerance/ 及 https://nightlies.apache.org/flink/flink-docs-stable/docs/ops/state/checkpointing_under_backpressure/

[5] Apache Kafka. Design 文档中的Using Transactions。https://kafka.apache.org/design/

[6] SQLite. Atomic Commit In SQLite 与Transaction。https://www.sqlite.org/atomiccommit.html 及 https://www.sqlite.org/lang_transaction.html

[7] 用户提供的海洋大数据课程材料学习记录 20261107 含第七讲更新。第五讲实时处理 窗口和端到端效果。
''')
    md='\n\n'.join(c)
    md=md.replace(r'^{\rm written}',r'^{\mathrm{written}}')
    md=md.replace(r'_{\rm last}',r'_{\mathrm{last}}')
    md=md.replace(r'{\bf1}',r'\mathbf{1}')
    md=md.replace(r'\widehat B_t',r'\widehat{B}_t')
    md=md.replace(r'\widehat d_t',r'\widehat{d}_t')
    md=md.replace(r'\widehat r_t',r'\widehat{r}_t')
    md=md.replace(r'\overline r_t',r'\overline{r}_t')
    # The named function also renders on readers with incomplete ceiling glyph support.
    md=md.replace(r'\left\lceil d_0+S_t/\widehat{B}_t\right\rceil',
                  r'\operatorname{ceil}(d_0+S_t/\widehat{B}_t)')
    md=re.sub(r'\\tag\{(\d+)\}',lambda m:r'\qquad ('+m.group(1)+')',md)
    (rep/'model_and_validation.md').write_text(md,encoding='utf-8')
    # Reference DOCX provides explicit, portable style defaults.
    default_ref=rep/'pandoc_reference.docx'
    default_ref.write_bytes(subprocess.check_output(['pandoc','--print-default-data-file','reference.docx']))
    ref=Document(default_ref); sec=ref.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=Inches(.78);sec.bottom_margin=Inches(.78)
    sec.left_margin=Inches(.78);sec.right_margin=Inches(.78)
    for st in ref.styles:
        if st.type==1:
            st.font.name='Noto Serif CJK SC';st.font.color.rgb=RGBColor(0,0,0)
            if st.element.rPr is None:st.element.get_or_add_rPr()
            st.element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Serif CJK SC')
    normal=ref.styles['Normal'];normal.font.size=Pt(10.5)
    normal.paragraph_format.line_spacing=1.27
    normal.paragraph_format.space_after=Pt(6)
    for name,size in [('Title',20),('Subtitle',12),('heading 1',15),('heading 2',12)]:
        st=next(s for s in ref.styles if s.name.lower()==name.lower())
        st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
        st.paragraph_format.space_before=Pt(12);st.paragraph_format.space_after=Pt(7)
        if name.startswith('heading'):st.paragraph_format.keep_with_next=True
    ref.save(rep/'reference.docx')
    out=rep/'检查点调度模型与公开AIS验证.docx'
    subprocess.run(['pandoc',str(rep/'model_and_validation.md'),'-o',str(out),
                    '--from=markdown+tex_math_dollars','--reference-doc='+str(rep/'reference.docx'),
                    '--resource-path='+str(rep)],check=True)
    doc=Document(out)
    math_pr=doc.settings.element.find(qn('m:mathPr'))
    if math_pr is None:
        math_pr=OxmlElement('m:mathPr');doc.settings.element.append(math_pr)
    math_font=math_pr.find(qn('m:mathFont'))
    if math_font is None:
        math_font=OxmlElement('m:mathFont');math_pr.append(math_font)
    math_font.set(qn('m:val'),'XITS Math')
    for sec in doc.sections:
        sec.page_width=Inches(8.5);sec.page_height=Inches(11)
        sec.top_margin=sec.bottom_margin=Inches(.78)
        sec.left_margin=sec.right_margin=Inches(.78)
        fp=sec.footer.paragraphs[0];fp.alignment=WD_ALIGN_PARAGRAPH.CENTER
        fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');fp._p.append(fld)
    for st in doc.styles:
        if st.type==1:
            st.font.color.rgb=RGBColor(0,0,0)
    # Pandoc may inherit decorative paragraph borders from its default styles.
    for root in (doc.styles.element, doc.element):
        for border in root.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    for tb in doc.tables:
        tb.alignment=WD_TABLE_ALIGNMENT.CENTER;tb.autofit=False
        nc=len(tb.columns)
        widths={2:[2.0,4.8],3:[1.35,3.65,1.8],4:[2.0,1.3,2.2,1.3],5:[1.5,1.3,1.4,1.3,1.3]}.get(nc,[6.8/nc]*nc)
        props=tb._tbl.tblPr
        borders=OxmlElement('w:tblBorders')
        for tag in ['top','left','bottom','right','insideH','insideV']:
            x=OxmlElement('w:'+tag);x.set(qn('w:val'),'single');x.set(qn('w:sz'),'4');x.set(qn('w:color'),'D9D9D9');borders.append(x)
        props.append(borders)
        for ri,row in enumerate(tb.rows):
            if ri==0:
                repeat=OxmlElement('w:tblHeader');row._tr.get_or_add_trPr().append(repeat)
            for ci,cell in enumerate(row.cells):
                cell.width=Inches(widths[ci]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                pr=cell._tc.get_or_add_tcPr()
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'DCE8EF' if ri==0 else ('F5F8FA' if ri%2==0 else 'FFFFFF'));pr.append(shade)
                mar=OxmlElement('w:tcMar')
                for side in ['top','bottom','left','right']:
                    v=OxmlElement('w:'+side);v.set(qn('w:w'),'85');v.set(qn('w:type'),'dxa');mar.append(v)
                pr.append(mar)
                for p in cell.paragraphs:
                    p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(3)
                    p.paragraph_format.line_spacing=1.15
                    for run in p.runs:
                        run.font.size=Pt(9.5);run.font.color.rgb=RGBColor(0,0,0)
                        if ri==0:run.bold=True
        for col,w in zip(tb.columns,widths):col.width=Inches(w)
    for p in doc.paragraphs:
        if p.style.name in ('Caption','Image Caption'):
            p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after=Pt(9)
        for r in p.runs:
            # Keep Word's native equation representation, only style regular runs.
            r.font.color.rgb=RGBColor(0,0,0)
    doc.save(out)
    import zipfile
    with zipfile.ZipFile(out) as z:
        xml=z.read('word/document.xml').decode()
        print('NATIVE_OMML',xml.count('<m:oMath'))
    print(out)

if __name__=='__main__':main()
