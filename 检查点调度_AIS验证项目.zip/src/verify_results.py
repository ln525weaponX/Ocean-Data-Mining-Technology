from pathlib import Path
import json,hashlib,zipfile
import numpy as np,pandas as pd
from study import ROOT

def main():
    checks={}
    meta=json.loads((ROOT/'provenance/download.json').read_text())
    assert hashlib.sha256((ROOT/'data/ais_records.csv').read_bytes()).hexdigest()==meta['csv_extract_sha256']
    checks['csv_sha256_matches_pinned_extract']=True
    df=pd.read_csv(ROOT/'data/ais_records.csv',parse_dates=['ts'])
    assert len(df)==84702 and df.MMSI.nunique()==100 and df.fid.is_unique
    assert int((df.ts.dt.hour<8).sum())==22550
    checks['source_rows_and_split']=True
    runs=pd.read_csv(ROOT/'results/test_runs.csv')
    assert len(runs)==700 and runs.seed.nunique()==20
    assert (runs.records==62152).all()
    assert (runs.lost_output_records==0).all() and (runs.duplicate_effect_records==0).all()
    ad=runs[runs.policy=='adaptive']
    assert len(ad)==100
    assert ((ad.publish_wait_p99<=60)&(ad.risk_exceed_fraction<=.01)).all()
    checks['all_100_adaptive_primary_runs_meet_budgets']=True
    checks['simulated_atomic_prefix_invariants']=True
    tx=pd.read_csv(ROOT/'results/transaction_fault_tests.csv')
    good=tx[tx.atomic]
    assert len(good)==24 and (good.missing_effects==0).all() and (good.duplicate_effects==0).all()
    assert good.window_counts_equal.all() and good.distinct_pairs_equal.all()
    assert tx[~tx.atomic].missing_effects.sum()>0 and tx[~tx.atomic].duplicate_effects.sum()>0
    checks['actual_sqlite_atomic_trials_and_negative_controls']=True
    sens=pd.read_csv(ROOT/'results/sensitivity_runs.csv')
    tune=pd.read_csv(ROOT/'results/sensitivity_training_runs.csv')
    assert len(sens)==132 and len(tune)==792
    assert set(tune.seed)<=set(range(4)) and set(sens.seed)<=set(range(100,106))
    checks['sensitivity_fixed_baselines_use_training_only']=True
    nb=json.loads((ROOT/'检查点调度_AIS复现实验.ipynb').read_text())
    for cell in nb['cells']:
        if cell['cell_type']=='code':
            assert cell['execution_count'] is not None
            assert not any(o['output_type']=='error' for o in cell['outputs'])
    checks['notebook_executed_without_errors']=True
    doc=ROOT/'report/检查点调度模型与公开AIS验证.docx'
    with zipfile.ZipFile(doc) as z:
        xml=z.read('word/document.xml').decode()
        assert xml.count('<m:oMathPara')>=8
        assert '\\tag{' not in xml and '\\widehat' not in xml
    checks['docx_native_equations_no_latex_fallback']=True
    for i in range(1,6):assert any((ROOT/'figures').glob(f'{i:02d}_*.png'))
    checks['five_standalone_figures']=True
    (ROOT/'results/verification.json').write_text(json.dumps(checks,indent=2))
    print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
