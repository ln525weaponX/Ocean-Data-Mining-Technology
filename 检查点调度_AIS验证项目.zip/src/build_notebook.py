from pathlib import Path
import io,json,contextlib,base64,uuid,sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from study import ROOT

def main():
    cells=[]
    def md(text):cells.append({'cell_type':'markdown','id':uuid.uuid4().hex[:8],'metadata':{},'source':text.splitlines(True)})
    def code(text):cells.append({'cell_type':'code','id':uuid.uuid4().hex[:8],'metadata':{},'source':text.splitlines(True),'execution_count':None,'outputs':[]})
    md('''# 检查点调度模型与公开 AIS 复现实验

本 Notebook 随项目压缩包提供，请在解压根目录运行，保持 data、src 和 results 与本文件同级。
公开事实是2017年7月5日哥德堡附近的AIS记录；12倍速回放、断链、检查点成本和进程故障均是显式实验条件。
已执行下面的代码单元。图表和输出来自实际运行，不是填入的示例值。
''')
    code('''from pathlib import Path
import sys, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
ROOT = Path.cwd()
if not (ROOT / 'src/study.py').exists() and (ROOT / 'checkpoint_study/src/study.py').exists():
    ROOT = ROOT / 'checkpoint_study'
assert (ROOT / 'data/ais_records.csv').exists(), '请先解压完整项目，并在其根目录运行本 Notebook'
sys.path.insert(0, str(ROOT / 'src'))
from study import Config, make_trace, simulate
data = pd.read_csv(ROOT / 'data/ais_records.csv', parse_dates=['ts'])
print(f'AIS记录 {len(data):,} 条；不同MMSI {data.MMSI.nunique()} 个')
print('时间范围', data.ts.min(), '至', data.ts.max())
''')
    md(r'''## 在线模型

设 $u_t$ 为已处理但未被成功检查点覆盖的记录量，$a_t$ 为最早待提交更新的年龄，$\widehat d_t$ 为预计快照完成时间，$\widehat r_t^+$ 为保守处理速率。局部决策为

$$\max h,\quad a_t+h+\widehat d_t+\delta\le D,\quad u_t+\widehat r_t^+(h+\widehat d_t+\delta)\le R.$$

滚动重估最晚可等待时间，预算即将耗尽时启动一致检查点。该规则为局部预测贪心策略，完整随机时域的全局最优性不在本次证明范围。
''')
    code('''cfg = Config()
trace = make_trace(data, 'test', 'combined', cfg)
fixed_interval = json.loads((ROOT / 'results/experiment_plan.json').read_text())['selected_fixed_interval']
single = []
for policy in ['fixed', 'adaptive']:
    result = simulate(trace, policy, cfg, seed=100, fixed=fixed_interval)
    single.append(result)
cols = ['policy','checkpoints','checkpoint_mib','publish_wait_p99','risk_exceed_fraction','replay_records']
print(pd.DataFrame(single)[cols].round(4).to_string(index=False))
''')
    md('''## 全部主实验结果

以下读取随项目提供的700次运行明细。每种场景20个故障种子，固定与在线策略使用相同的故障和输入。
发布等待P99列先逐次运行计算，再在种子间求均值。全部性能时间以回放秒计。
''')
    code('''runs = pd.read_csv(ROOT / 'results/test_runs.csv')
main = runs[runs.policy.isin(['fixed','adaptive'])]
summary = main.groupby(['scenario','policy'])[['checkpoint_mib','publish_wait_p99','replay_per_failure','risk_exceed_fraction']].mean()
print(summary.round(4).to_string())
adaptive = runs[runs.policy == 'adaptive']
passed = (adaptive.publish_wait_p99 <= cfg.visible_budget) & (adaptive.risk_exceed_fraction <= 0.01)
print('满足两项验收条件', int(passed.sum()), '/', len(passed))
''')
    code('''fig, ax = plt.subplots(figsize=(8, 4))
summary['checkpoint_mib'].unstack('policy')[['fixed','adaptive']].plot.bar(ax=ax, color=['#C87C3C','#146B8C'])
ax.set_ylabel('Checkpoint writes (MiB)')
ax.set_xlabel('Held-out scenario')
ax.set_title('Checkpoint IO under identical input and failures')
ax.spines[['top','right']].set_visible(False)
plt.tight_layout()
plt.show()
''')
    md('''## 检查真实事务故障回放

事务试验实际使用SQLite，报文计数执行累加操作，审计日志没有fid唯一约束。游标和业务效果在同一事务提交。
它核验单库事务边界，没有代替分布式Flink故障试验。
''')
    code('''tx = json.loads((ROOT / 'results/transaction_check_summary.json').read_text())
print(json.dumps(tx, indent=2, ensure_ascii=False))
assert tx['missing_effects'] == 0 and tx['duplicate_effects'] == 0
assert tx['all_counts_equal']
''')
    md('''## 继续实验

修改 Config 中的预算、能力或带宽后，可以重新调用 simulate。完整重跑命令：

```bash
python src/study.py
python src/transaction_check.py
python src/make_figures.py
```

主结果应解释为资源与恢复代价的权衡。自适应策略减少了检查点写入，同时增大了等待和重算量；先确认预算适合业务，再评价资源收益。
''')
    ns={'__name__':'__main__'};counter=0
    import os
    old=os.getcwd();os.chdir(ROOT)
    try:
        for cell in cells:
            if cell['cell_type']!='code':continue
            counter+=1;stdout=io.StringIO();images=[]
            original_show=plt.show
            def capture_show(*args,**kwargs):
                for n in plt.get_fignums():
                    b=io.BytesIO();plt.figure(n).savefig(b,format='png',dpi=140,bbox_inches='tight')
                    images.append(base64.b64encode(b.getvalue()).decode())
                plt.close('all')
            plt.show=capture_show
            try:
                with contextlib.redirect_stdout(stdout):exec(''.join(cell['source']),ns)
            finally:plt.show=original_show
            cell['execution_count']=counter
            if stdout.getvalue():cell['outputs'].append({'output_type':'stream','name':'stdout','text':stdout.getvalue().splitlines(True)})
            for im in images:cell['outputs'].append({'output_type':'display_data','metadata':{},'data':{'image/png':im,'text/plain':['<Figure>']}})
    finally:os.chdir(old)
    notebook={'nbformat':4,'nbformat_minor':5,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},
                'language_info':{'name':'python','version':sys.version.split()[0]}},'cells':cells}
    out=ROOT/'检查点调度_AIS复现实验.ipynb'
    out.write_text(json.dumps(notebook,ensure_ascii=False,indent=1),encoding='utf-8')
    print('Executed notebook',counter,'code cells',out)

if __name__=='__main__':main()
